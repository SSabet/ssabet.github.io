function [Ah_new_t, Bh_new_t, C_t, g_t, A_t, Fric_t, vNew, Sb_t, Sa_t] = ...
    block_hh_tr_fn(ra_t, rb_t, w_t, L_t, tau_t, par, grids, Z_exo)
%{
HOUSEHOLD BLOCK - sector j
===========================================================================
INPUT: rb, ra, wj, T, L
OUTPUT: A^h, B^h, C
%}

% Check the parameter values are valid
assert(par.chi0 < 1,'chi0 large, not interesting!');

% -------------------------------------------------------------------------
% Pre-computations
deathrate = par.deathrate;
I = par.I; J = par.J; 
xi = par.xi;

% Construct exogeneous transition matrices
% Poisson transition matrix between exogenous states
Bswitch     = kron(par.la_mat, speye(I*J));

% Death
% [val0, idx0] = min(abs(grids.b));

% -------------------------------------------------------------------------
% Solve stationary policies & value

vNew = par.vNew; % steady state value

% Store sequences

seq.w_t = w_t;
seq.L_t = L_t;
seq.tau_t = tau_t;
seq.T_t = Z_exo.T_t;
seq.rho_t = Z_exo.rho_t;

% Main loop
for n=par.N:-1:1
    
    Rb = rb_t(n).*(grids.bbb>=0) + (rb_t(n)+par.spread).*(grids.bbb<0) + deathrate;
    Ra = ra_t(n).*(grids.aaa >= 0) + deathrate;
     
    % Two particular (arrays of) points on the d-domain
    d_zerodrift = -(Ra .* grids.aaa + xi*(1-tau_t(n)) * w_t(n)*L_t(n) * grids.zzz); % The d policy that ensures zero a-drift
    d_lower     = (par.chi0-1)/par.chi1.*grids.aaa; % The d policy at which marginal adjustment cost equals withdrawal

    % Relabel the current value guess
    vOld = vNew;
    
    % Update policies & value
    try
    [c,d,sb,sa,vNew,A] = updateHousehold_tr(vOld,Rb,Ra,d_zerodrift,d_lower,Bswitch, grids,par,seq,n);
    catch
        fprintf('');
    end
    A_t{n} = A;
    c_t{n} = c;
    d_t{n} = d;
    sb_t{n} = sb;
    sa_t{n} = sa;
end

% -------------------------------------------------------------------------
% Solve stationary distribution

[C_t, Bh_new_t, Ah_new_t, g_t, Fric_t, Sb_t, Sa_t] = KFE(A_t, c_t, d_t, sb_t, sa_t, par, grids);

end
