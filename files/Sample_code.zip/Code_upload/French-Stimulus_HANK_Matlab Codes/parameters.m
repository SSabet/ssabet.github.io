function par = parameters()   
    %% Preferences
    par.gamma = 1;
    par.rho = 0.06;
    frisch_eols = 1.; % Frisch elasticity: Soroush
    par.frisch = 1/frisch_eols; % inverse of Frisch elasticity of labour supply
    par.phi = .0121; % coefficient of disutility of labour
    par.spread = 0.08;
    par.deathrate = 1/45;

    %% Union
    par.varepsilon = 10;
    par.PCcoeff = .01;
    par.psi = 100; % coefficient of convex wage adjustment cost

    % which wage Phillips curve function use to back out labour?
    % options are 'ad-hoc', 'linear' & 'non-linear' (the latter two are
    % micro-founded); 'quadratic' added
    % 'linear' and 'ad-hoc' work better for coarser (or unregular) time grids
    par.use_adhoc_PC = 'linear'; 

    %% Inflation and Monetary Policy
    par.stickywage = 1;
    par.phi_pi = 1.1; % Taylor rule parameter
 
    %% Fiscal Policy parameters
    par.T = 2.2061*1.02;
    par.tau = .3; % average labor income tax in France
    par.kappa = 1;

    
    varsigma_l = 0;
    varsigma_y = 0.25;
    varsigma_k = 0;
    par.G = 3.0742*1.0;
    
    par.S = 5; % number of production sectors

    par.varsigma_ls = varsigma_l*ones(par.S,1);
    par.varsigma_ys = varsigma_y*ones(par.S,1);
    par.varsigma_ks = varsigma_k*ones(par.S,1);
    

    % (phi_r=1,phi_l=tau-varsigma_w) => gov debt adjusts, see Alves et al
    % eq 26 and footnote 42
    
    par.phi_r = 1;
    par.phi_l = par.tau;
    par.phi_b = .25;

    par.Bf_bar = 0.0;

    %% Production
    par.alpha = .3919;
    par.depreciation = 0.075;
    par.Z = 1.;
    
    par.alphas = [1; 1; 1.; 1.; 1.]*par.alpha; % sectoral capital intensity
    par.Zs = [1.; 1.; 1.; 1.; 1.]*par.Z; % sectoral Hicks-neutral productivity index
    
    % elasticity of substitution b/w sectors in final output
    par.varepsilon_c = 0.9;    % sectoral share coefficients in final output

    omegas = [0.015926052; 0.101539041; 0.057246744; 0.133953754; 0.691333944];
    par.omegas = omegas/sum(omegas);
    
    % zetas are proportional to sectoral capital-labour ratios
    par.zetas = par.alphas./(1-par.alphas)...
        .* (1+ par.varsigma_ks) ./ (1+ par.varsigma_ls);

    par.zeta_sum = sum(par.zetas);

    %% Illiquid asset parameters
    par.chi0 = 0.01; % Linear adjustment cost
    par.chi1 = 24.883; % Convex adjustment cost
    par.xi   = 0.1; % Automatic proportion of labour earnings to illiquid
    
    %% Labor Process (Poisson shocks)       
    load 'calibration.mat';

    par.g_z = calib.g_z;
    par.la_mat = calib.la_mat;
    par.K = calib.K;
    par.z = calib.z;
    
    %% Asset grid settings
    par.I          = 30;
    par.bmin       = -1.0;
    par.bmax       = 35;
        
    par.J          = 19;
    par.amin       = 0.;
    par.amax       = 1500.0;
    
    par.M = par.I*par.J*par.K;
    
    % Grid types: you can choose from  
    % 'Linear'       = equispaced,  
    % 'NL_symmetric' = nonlinear with concentration of points on both ends,
    % 'NL_lefts'     = nonlinear grid with concentration of points at the left end (lower bound),
    % 'NL_rights'    = nonlienar grid with concentration of points at the right end
    par.bgrid_type = 'NL_lefts';
    par.agrid_type = 'NL_lefts';
    %par.agrid_type = 'Linear';
    
    %% Estimation parameters
    par.crit  = 1e-12;
    par.Delta = 1e6;
    par.maxit = 35;
    
    %% Lockdown
    par.lockdown = .75;
    par.N = 23;
    par.Tend = 50;
    par.tgrid_type = 'Custom';

    %% Transition Solution
    % par.fix_rb_N = true;

    %% Aggregate data

    par.GDP_stationary = 2425700000000;
    par.numhh = 29198686;
    par.employment = 27360000;

    %% Cosmetics
    par.c1 = uint8([80, 136, 164]);
    par.c2 = uint8([94, 164, 80]);
    par.c3 = uint8([164, 108, 80]);
    par.c4 = uint8([181,99,101]);

end




