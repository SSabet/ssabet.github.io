function [Ah_new, Bh_new, C, Chi, g, A, Sb, c, sb, sa, d, vNew, g_newborn] = block_hh_ss_fn(ra, rb, w, L, par, grids)

%{
HOUSEHOLD BLOCK - sector j
===========================================================================
INPUT: rb, ra, wj, T, L
OUTPUT: A^h, B^h, C
%}

   
% Check the parameter values are valid
assert(par.chi0 < 1,'chi0 large, not interesting!');
assert(ra*par.chi1 < 1-par.chi0, 'ra too large, illiquid wealth accumulates to infinity');

deathrate = par.deathrate;
I = par.I; J = par.J; K = par.K;
M = par.M;
tau = par.tau;
xi = par.xi;

maxit = par.maxit;
crit = par.crit;
% -------------------------------------------------------------------------
% Pre-computations

% Grid of effective asset returns (so including the discounting from death
% rate)
raa = ones(1,J)*ra;

rb_neg= rb + par.spread;
Rb = rb.*(grids.bbb>=0) + rb_neg.*(grids.bbb<0) + deathrate;
Ra = repmat(ones(I,1)*raa,1,1,K) + deathrate;
 
% Two particular (arrays of) points on the d-domain
d_zerodrift = -(Ra .* grids.aaa + xi*(1-tau) * w*L * grids.zzz); % The d policy that ensures zero a-drift
d_lower     = (par.chi0-1)/par.chi1.*grids.aaa; % The d policy at which marginal adjustment cost equals withdrawal

% Construct exogeneous transition matrices
% Poisson transition matrix between exogenous states
Aswitch     = kron(par.la_mat, speye(I*J));

[~, idx0] = min(abs(grids.b));

% Death
newborn_idx = ((1:K)-1)*I*J+ 0 + idx0;
g_newborn = zeros(M,1);
g_newborn(newborn_idx) = par.g_z; % distribution of newborns on state space
par.g_newborn = g_newborn;

% -------------------------------------------------------------------------
% Solve stationary policies & value

% Initial guess
v0 = U((1-tau)*(1-xi)*w*L*grids.zzz + Ra.*grids.aaa + Rb.*grids.bbb,par)/par.rho;

vNew = v0; % the most recent guess
v0_alt = v0; % the previous good guess for adaptive Delta


% Main loop
dist = ones(maxit,1);
slowCount = 0; % number of slowed down iterations
for n=1:maxit
    try
        % Relabel the current value guess
        vOld = vNew;
    
        % Update policies & value
        [c,d,sb,sa,vNew,A] = updateHousehold(vOld,Rb,Ra,d_zerodrift,d_lower,Aswitch, grids,par);
    
        % Check convergence & iterate
        vChange = vOld - vNew;
    
        dist(n) = max(max(max(abs(vChange))));
        if dist(n)<crit

            break
        end
    catch
        vNew = v0_alt; %Reset the starting guess
        par.Delta = .5; %Slow things down
        slowCount = 1;
    end

    if slowCount >0
        slowCount = slowCount + 1;
        if slowCount > 10
            v0_alt = vNew;
            slowCount = 0;
            par.Delta = 1e8;
        end
    end
end

if (n == maxit)
    fprintf('Not fully converged with last Vchange = %f. \n', dist(n));
end
% -------------------------------------------------------------------------
% Solve stationary distribution

g = stationary_measure(A, par);
g = max(0,g); g = g/sum(g(:));

% Output
% ===============================================================

chi_hh = two_asset_kinked_cost(d, grids.aaa, par.chi0, par.chi1);

Ah_new = sum(grids.aaa(:).*g(:));
Bh_new = sum(grids.bbb(:).*g(:));
C = sum(c(:).*g(:));
Chi = sum(chi_hh(:).*g(:));
Sb = sum(sb(:).*g(:));

end
















