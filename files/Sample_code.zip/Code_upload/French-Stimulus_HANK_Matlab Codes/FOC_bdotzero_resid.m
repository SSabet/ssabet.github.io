function noarb = FOC_bdotzero_resid(b,a,zk,d,Va,forward,rb,par)
    chi0 = par.chi0;
    chi1 = par.chi1;
        
    noarb = MU(rb*b + (1-par.xi)*(1-par.tau)*par.w*par.L*zk + par.T - d - two_asset_kinked_cost(d, a, chi0, chi1),par.gamma).*...
            (1 + chi0 * (2*forward - 1) + chi1 * d /a) - Va;
end


function mu = MU(c, gamma)
    mu = c.^(-gamma);
end
