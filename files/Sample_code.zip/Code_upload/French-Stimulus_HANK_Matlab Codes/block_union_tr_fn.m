function [L_new_t, pi_t] = block_union_tr_fn(ra_t, rb_t, w_t, C_t, tau_t, Ls_t, Ks_t, Y_t, Ys_t, par, grids, Z_exo)

    %{
      UNION BLOCK
      ===========================================================================
    %}

    cellfun(@(x) assignin('caller', x, grids.(x)), fieldnames(grids));
    
    % use nominal price of sector 1, to calculate the wage inflation
    varsigma_l_t = Z_exo.varsigma_l_t(:,1);
    varsigma_k_t = Z_exo.varsigma_k_t(:,1);
    varsigma_y_t = Z_exo.varsigma_y_t(:,1);
    kappa_t = Z_exo.kappa_t(:,1);
    
    N = par.N;
    varepsilon_c = par.varepsilon_c;
    alpha1 = par.alphas(1);

    %% Use Taylor rule and Fisher equation to get inflation of the final output

    % Soroush: Taylor & Fisher (27/10/2024)
    ZLB = (- par.rb + par.phi_pi*rb_t)<0;
    pi_t = (rb_t-par.rb)./(par.phi_pi-1-rb_t).*(1-ZLB) - rb_t.*ZLB;

    
    rk_t = ra_t + par.depreciation;
    
    %% Use FOC of the final good producer to get inflation of the first sector
    Y_dot_t = zeros(N,1);
    Y_dot_t(1:N-1,1) = (Y_t(2:N) -  Y_t(1:N-1))./dt_F(1:N-1);

    Y1_dot_t = zeros(N,1);
    Y1_dot_t(1:N-1,1) = (Ys_t(2:N,1) -  Ys_t(1:N-1,1))./dt_F(1:N-1);
    
    pi_1_t = pi_t + (Y_dot_t./Y_t - Y1_dot_t./Ys_t(:,1))/varepsilon_c;

    %% Compute wage inflation, from firms' problem and inflation
    %' First method: use growth rate of w_t, rk_t: real wage and gross
    % return to capital

    % time derivative rk
    rk_dot_t = zeros(N,1);
    rk_dot_t(1:N-1,1) = (rk_t(2:N) -  rk_t(1:N-1))./dt_F(1:N-1);
    % time derivative kappa
    kappa_dot_t = zeros(N,1);
    kappa_dot_t(1:N-1,1) = (kappa_t(2:N) -  kappa_t(1:N-1))./dt_F(1:N-1);

    % time derivative varsigma_l
    varsigma_l_dot_t = zeros(N,1);
    varsigma_l_dot_t(1:N-1,1) = (varsigma_l_t(2:N) -  varsigma_l_t(1:N-1))./dt_F(1:N-1);
    % time derivative varsigma_k
    varsigma_k_dot_t = zeros(N,1);
    varsigma_k_dot_t(1:N-1,1) = (varsigma_k_t(2:N) -  varsigma_k_t(1:N-1))./dt_F(1:N-1);
    % time derivative varsigma_y
    varsigma_y_dot_t = zeros(N,1);
    varsigma_y_dot_t(1:N-1,1) = (varsigma_y_t(2:N) -  varsigma_y_t(1:N-1))./dt_F(1:N-1);

    % Wage Inflation, equation derived from time derivative of log of real
    % wage (FOC of firm, using w_t/rk_t)

    pi_w_t = pi_1_t ...
        + kappa_dot_t./kappa_t...
        - alpha1/(1-alpha1)*rk_dot_t./rk_t...
        - alpha1/(1-alpha1)*varsigma_k_dot_t./(1+varsigma_k_t)...
        + (1 + alpha1)/(1- alpha1)*varsigma_l_dot_t./(1 + varsigma_l_t)...
        - 1/(1-alpha1)*varsigma_y_dot_t./(1-varsigma_y_t);


    pi_w_dot_t = zeros(N,1);
    pi_w_dot_t(1:N-1,1) = (pi_w_t(2:N) -  pi_w_t(1:N-1))./dt_F(1:N-1);
    
    if par.stickywage == 1
        L_new_t = solve_Lt(pi_w_t, pi_w_dot_t, w_t, C_t, tau_t, Z_exo.phi_t, par);
    else
        % Flex price case
        L_new_t = ((par.varepsilon-1)/par.varepsilon.*C_t.^(-par.gamma).*(1-tau_t).*w_t/par.phi).^(1/par.frisch);
    end
   
end
