function Bf = block_foreign_fn(par,r)

Bf = par.Bf_bar./(par.rho-r);

