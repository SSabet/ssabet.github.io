function [Y_t, ra_t, w_t, Kprod_t, L_t, Ys_t, Ps_t, Ks_t, Ls_t] = block_firms_tr_fn(K1_t, L1_t, par, Z_exo)

    %{
      FIRM BLOCK - sector j
      ===========================================================================
    %}

    kappa_t = Z_exo.kappa_t;
    varsigma_l_t = Z_exo.varsigma_l_t;
    varsigma_y_t = Z_exo.varsigma_y_t;
    varsigma_k_t = Z_exo.varsigma_k_t;
    zetas_t = Z_exo.zetas_t;
    alphas_t = Z_exo.alphas_t;
    
    S = par.S;
    omegas = par.omegas;
    varepsilon_c = par.varepsilon_c;

    % capital-labour ratio in sectors: proportional to zetas
    kl1_t = K1_t./L1_t;
    kls1_t = repmat(kl1_t, 1, S);
    kls_t = zetas_t./repmat(zetas_t(:,1), 1, S).*kls1_t;
    
    % sectoral TFPs
    TFPs_t = par.Z * kappa_t.^(1-alphas_t);
    
    % sectoral prices are proportional to Chis at each period
    chis_t = 1./(alphas_t.* (1-varsigma_y_t).* (1+ varsigma_k_t).* TFPs_t...
        .* (kls_t.^(alphas_t -1))); % dimenstion: N x S

    Ps_t = chis_t .* repmat((chis_t.^(1-varepsilon_c)*omegas).^(1/(varepsilon_c - 1)), 1, S);
    
    % wage rate and gross rate of return to capital
    rk_t = alphas_t(:,1).*Ps_t(:,1).*TFPs_t(:,1).*(1-varsigma_y_t(:,1)).*(1+varsigma_k_t(:,1)).*kl1_t.^(alphas_t(:,1)-1);
    w_t = (1-alphas_t(:,1)).*Ps_t(:,1).*TFPs_t(:,1).*(1-varsigma_y_t(:,1)).*(1+varsigma_l_t(:,1)).*kl1_t.^(alphas_t(:,1));


    % sectoral outputs
    Y1_t = TFPs_t(:,1).*K1_t.^(alphas_t(:,1)).*L1_t.^(1-alphas_t(:,1));
    Ys_t = repmat(omegas'/omegas(1), par.N, 1) .* (repmat(Ps_t(:,1), 1, S)./Ps_t).^varepsilon_c .* repmat(Y1_t, 1, S);
    
    
    % Final output
    Y_t = sum(Ys_t .* Ps_t, 2);
    
    Ls_t = Ys_t ./ TFPs_t ./ (kls_t .^ alphas_t);
    Ks_t = kls_t .* Ls_t;
    
    Kprod_t = sum(Ks_t, 2);
    L_t= sum(Ls_t, 2);

%% ra
    ra_t = rk_t-par.depreciation;
end

