function [Y, ra, w, Kprod, L, Ys, Ps, Ks, Ls] = block_firms_ss_fn(K1, L1, par)
%{
FIRM BLOCK - sector j
===========================================================================
INPUT: L1, K1 (labour and capital in the first/base sector)
OUTPUT: Y (GDP), ra, w, Ys (sectoral output vector), K, L (aggregate capital and
output)
%}

cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));

% capital-labour ratio in sectors: proportional to zetas
kl1 = K1/L1;
kls = zetas/zetas(1)*kl1;

% sectoral TFPs
TFPs = Z * kappa.^(1-alphas);

% normalise price of final output to 1
% sectoral prices are proportional to Chis
chis = 1./(alphas.* (1-varsigma_ys).* (1+ varsigma_ks).* TFPs...
    .* (kls.^(alphas -1)));
Ps = chis * (sum(omegas.* chis.^(1-varepsilon_c)))^(1/(varepsilon_c - 1));

% wage rate and gross rate of return to capital
rk = alphas(1)*Ps(1)*TFPs(1)*(1-varsigma_ys(1))*(1+varsigma_ks(1))*kl1^(alphas(1)-1);
w = (1-alphas(1))*Ps(1)*TFPs(1)*(1-varsigma_ys(1))*(1+varsigma_ls(1))*kl1^(alphas(1));

% sectoral outputs
Y1 = TFPs(1)*K1^(alphas(1))*L1^(1-alphas(1));
Ys = omegas/omegas(1) .* (Ps(1)./Ps).^varepsilon_c * Y1;


% Final output
Y = sum(Ys .* Ps);

Ls = Ys ./ TFPs ./ (kls .^ alphas);
Ks = kls .* Ls;

Kprod = sum(Ks);
L = sum(Ls);

ra = rk-depreciation;

end
