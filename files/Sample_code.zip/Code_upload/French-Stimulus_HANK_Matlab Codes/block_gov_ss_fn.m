function Bg = block_gov_ss_fn(w, rk, Ls, Ks, Ys, Ps, rb, par)
%{
GOVERNMENT BLOCK
===========================================================================
INPUT: varsigma_w, T, G, L, w, tau
OUTPUT: Bg
%}

Bg = -(par.G + par.T + sum(par.varsigma_ls./(1+par.varsigma_ls).*(w*Ls)) + sum(par.varsigma_ks./(1+ par.varsigma_ks).*(rk*Ks)) -...
    sum(par.varsigma_ys.*Ps.*Ys) - par.tau*w*sum(Ls))/rb;

if Bg<0
    fprintf('\n Gb negative, adjust policy parameters \n')
    return
end
end
































