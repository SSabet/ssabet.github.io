function [ra,rb, L, Kprod ,w,g,vNew,Bg,Y,C, Chi, g_newborn,Ys, Ps, Ls, Ks] = get_ss(agg, par, grids)
    
    K1 = exp(agg(1));
    L1 = exp(agg(2));
        
    rb = agg(3);
    
    % Firm block
    % =========================================================================
    % INPUT: L, K, varsigma_w, varsigma_w, kappa | OUTPUT: Y, ra, w
    [Y, ra, w, Kprod, L, Ys, Ps, Ks, Ls] = block_firms_ss_fn(K1, L1, par);
    
    % Store GE parameters
    par.w = w;
    par.L = L;
    par.rb = rb;
    par.ra = ra;
    
    rk = ra + par.depreciation;
    
       
    %% Government block
    % =========================================================================
    % INPUT: tau, varsigma_w, T, G, L | OUTPUT: Bg
    Bg = block_gov_ss_fn(w, rk, Ls, Ks, Ys, Ps, rb, par);

    % Household block
    % =========================================================================
    % INPUT: rb, ra, w, T, L | OUTPUT: Bh_new, Ah_new, C
    [Ah_new, Bh_new, C, Chi, g, A, ~, c, ~, ~, d,vNew, g_newborn] =...
        block_hh_ss_fn(ra, rb, w, L, par, grids);
    
    
    % Union block
    % =========================================================================
    % INPUT: w, tau, C | OUTPUT: L_new
    L_new = block_union_ss_fn(w, C, par);

    % Foreign supply of bonds
    % =========================================================================

    Bf = block_foreign_fn(par,rb);

    % Computing the MPC, and Plots
    % =========================================================================

    % Partial distributions
    g_b = sum(sum(g,3),2);
    g_a = sum(sum(g,3));
    % g_z = sum(sum(g,2));

    % Aggregate objects
    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par)); % dynamic assignments more readable but not efficient

    wL = w*L_new;
    D = sum(d(:).*g(:));
    cchi = two_asset_kinked_cost(d, grids.aaa, chi0, chi1);
    CHI = sum(cchi(:).*g(:));
    kkappa = -spread*grids.bbb.*(grids.bbb<0);
    KAPPA = sum(kkappa(:).*g(:));

    Bdot = (1-xi)*(1-tau)*wL-D-C-CHI-KAPPA+rb*Bh_new + T;
    Adot = xi*(1-tau)*wL + D + ra*Ah_new;
    Bgdot = G + T + sum(par.varsigma_ls./(1+par.varsigma_ls).*(w*Ls)) ...
        + sum(par.varsigma_ks./(1+ par.varsigma_ks).*(rk*Ks))...
        - sum(par.varsigma_ys.*Ps.*Ys) - tau*w*sum(Ls) + rb*Bg;
    
    % Computing MPC
    
    % Parameters for MPC
    tau_mpc = 1/4; % Tau is the MPC period (quarter here)
    N_fk = 20; % Granularity of the time grid
    dt = tau_mpc/(N_fk-1);
    
    % Solve Feynman-Kac equation
    % Assume that at the end of tau_mpc (the quarter) the Gamma function is 0 (FK
    % terminal condition)   
    C_stacked = zeros(par.M,N_fk); % Preallocate: L tot gridpoints N_fk tot periods
    c_stacked = reshape(c,par.M,1); % Put c over a column vector
    B = (1/dt)*speye(par.M) - A;
    
    for n=N_fk-1:-1:1
        vec = c_stacked+C_stacked(:,n+1)/dt; 
        C_stacked(:,n) = B\vec; 
    end
    
    cc = reshape(C_stacked(:,1),I,J,K); % First time element
    mpc = (cc(2:end,:,:)-cc(1:end-1,:,:))./(grids.bbb(2:end,:,:)-grids.bbb(1:end-1,:,:)); % Change in C along a dimension over change in a in the grid
    mpc(par.I,:,:) = mpc(par.I-1,:,:);
    mpc_av = sum(g(:).*mpc(:));
    mpc_b = sum(sum(mpc.*g,2),3)./g_b;

    figure(1)
    set(gcf,'position',[100,40,1300,300])
    subplot(1,4,1)
    plot(grids.a,g_a,'LineWidth',2,'Color',uint8([80, 136, 164]))
    ylabel('illiquid asset')
    ylim([0 1.05*max(g_a(2:end))])
    subplot(1,4,2)
    plot(grids.b,g_b,'LineWidth',2,'Color',uint8([181,99,101]))
    ylabel('liquid asset')
    subplot(1,4,3)
    plot(par.z,par.g_z,'LineWidth',2,'Color',uint8([181,99,101]))
    ylabel('income')
    subplot(1,4,4)
    plot(grids.b,mpc_b*100,'LineWidth',2,'Color',uint8([181,99,101]))
    xlim([par.bmin par.bmax*0.9])
    ylabel('Monthly MPC along liquid asset')


    %% Plot distributions
    
    sup_a = grids.a/Y*par.GDP_stationary/10e3/par.numhh;
    sup_b = grids.b/Y*par.GDP_stationary/10e3/par.numhh;

    if par.US_calib==1
    
        figure(1)
        close; set(gcf,'position',[100,40,600,600])
        plot(sup_a,g_a,'LineWidth',3,'Color',uint8([80, 136, 164]))
        xlim([min(sup_a) max(sup_a)])
        ylabel('masse','Interpreter', 'latex')
        xlabel('milliers d''euros','Interpreter', 'latex')
        ylim([0 1.05*max(g_a(2:end))])
        set(gca,'FontSize',20,'box','off','TickLabelInterpreter', 'latex')
        print('-dpng', '-r300','../Output/distributions_il_US.png');
            
        figure(2)
        close; set(gcf,'position',[100,40,600,600])
        plot(sup_b,g_b,'LineWidth',3,'Color',uint8([181,99,101]))
        xlim([min(sup_b) max(sup_b)])
        ylabel('masse','Interpreter', 'latex')
        xlabel('milliers d''euros','Interpreter', 'latex')
        set(gca,'FontSize',20,'box','off','TickLabelInterpreter', 'latex')
        print('-dpng', '-r300','../Output/distributions_li_US.png');

    else

        figure(1)
        close; set(gcf,'position',[100,40,600,600])
        plot(sup_a,g_a,'LineWidth',3,'Color',uint8([80, 136, 164]))
        xlim([min(sup_a) max(sup_a)])
        ylabel('masse','Interpreter', 'latex')
        xlabel('milliers d''euros','Interpreter', 'latex')
        ylim([0 1.05*max(g_a(2:end))])
        set(gca,'FontSize',20,'box','off','TickLabelInterpreter', 'latex')
        print('-dpng', '-r300','../Output/distributions_il.png');
            
        figure(2)
        close; set(gcf,'position',[100,40,600,600])
        plot(sup_b,g_b,'LineWidth',3,'Color',uint8([181,99,101]))
        xlim([min(sup_b) max(sup_b)])
        ylabel('masse','Interpreter', 'latex')
        xlabel('milliers d''euros','Interpreter', 'latex')
        set(gca,'FontSize',20,'box','off','TickLabelInterpreter', 'latex')
        print('-dpng', '-r300','../Output/distributions_li.png');

    end


    %% Steady state moments (targeted and untargeted)

    GDP = Y - (CHI + KAPPA);
    
    % clc
    disp(['Consumption to GDP = ',num2str(C/GDP*100),'% (target = 53%)'])
    disp(['Gross investment to GDP = ',num2str(depreciation*Kprod/GDP*100),'% (target = 24%)'])
    disp(['Gov exp to GDP = ',num2str(G/GDP*100),'% (target = 23%)'])
    disp(['Exports to GDP = ',num2str(rb*Bf/GDP*100)])
    disp(['Frictions to GDP = ',num2str((CHI + KAPPA)/Y*100)])
    disp(['Capital to GDP ratio = ',num2str(Kprod/Y)])
    disp(['rb = ',num2str(rb*100),'%'])
    disp(['ra = ',num2str(ra*100),'%'])
    disp(['Debt to GDP = ',num2str(Bg/Y*100),'%'])
    disp(['Transfers to GDP = ',num2str(T/Y*100),'%'])
    disp(['Prim. surplus to GDP = ',num2str((par.tau*w*L-par.T-par.G)/Y*100),'%'])
    disp(['Average MPC = ',num2str(mpc_av*100),'%'])
    disp(['Share HtM = ',num2str(sum((grids.bbb(:)==0).*g(:))*100),'%'])
    disp(['Illiquid transfer = ',num2str(D)])

    disp([newline,'All the following should be 0 in SS:', newline])

    disp(['Market clearing K = ',num2str((Kprod-Ah_new)/Kprod*100),'%'])
    disp(['Market clearing L = ',num2str((L-L_new)/L*100),'%'])
    disp(['Market clearing B = ',num2str((Bg-(Bh_new+Bf))/Bg*100),'%'])
    disp(['Market clearing Y = ',num2str((Y-GDP-(CHI + KAPPA))/Y*100),'%'])
    disp(['A dot = ',num2str(Adot)])
    disp(['B dot = ',num2str(Bdot)])
    disp(['Public debt issuance = ',num2str(Bgdot)])

end













