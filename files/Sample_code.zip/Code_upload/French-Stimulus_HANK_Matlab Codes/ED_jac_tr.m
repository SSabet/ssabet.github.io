function ED_t = ED_jac_tr(X, Z_exo, par, grids)
    
% Assign parameters
    cellfun(@(x) assignin('caller', x, Z_exo.(x)), fieldnames(Z_exo));
    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    cellfun(@(x) assignin('caller', x, grids.(x)), fieldnames(grids));
    
    % Endogeneous response
    
    K1_t = exp(X(1:N));
    L1_t = exp(X(N+1:2*N));
    rb_t = [X(2*N+1:end)];
    
    % Firm block
    % =========================================================================
    %run block_firms_tr.m
    [Y_t, ra_t, w_t, Kprod_t, L_t, Ys_t, Ps_t, Ks_t, Ls_t] = block_firms_tr_fn(K1_t, L1_t, par, Z_exo);
    
    rk_t = ra_t + par.depreciation;


    % Government block
    % =========================================================================
    [~, Bgdot_t, tau_t] = block_gov_tr_fn(w_t, rk_t, Ls_t, Ks_t, Ys_t, Ps_t, rb_t, par, Z_exo, grids.dt_F);

    % Household block
    % =========================================================================
    [Ah_new_t, Bh_new_t, C_t, ~, ~, Fric_t, ~, Sb_t, Sa_t] = block_hh_tr_fn(ra_t, rb_t, w_t, L_t, tau_t, par, grids, Z_exo);
    
    % Union block
    % =========================================================================
    [L_new_t, ~] = block_union_tr_fn(ra_t, rb_t, w_t, C_t, tau_t, Ls_t, Ks_t, Y_t, Ys_t, par, grids, Z_exo);
    
    % Foreign supply of bonds
    % =========================================================================

    Bf_t = block_foreign_fn(par,rb_t);

    % Excess demand
    % =========================================================================
    ED_L_t = (L_t-L_new_t)./L_t;
    

    % Net exports
    %  Bf_dot_t = Bgdot_t - Sb_t;
    Bf = block_foreign_fn(par,rb); % SS Bf

    Bf_dot_t = zeros(N,1);
    Bf_dot_t(1:N-1) = (Bf_t(2:N) - Bf_t(1:N-1))./dt_F(1:N-1); Bf_dot_t(N) = (Bf_t(N) - Bf)/dt_F(N);

    Netexp_t = Bf_t.*rb_t-Bf_dot_t;
    
    ED_Bdot_t = Bgdot_t - Bf_dot_t - (Sb_t - deathrate*Bh_new_t);
    
    I_t = (Sa_t - deathrate*Ah_new_t) + depreciation*Kprod_t;
    ED_Y_t = Y_t - (I_t + C_t + Fric_t + G_t + Netexp_t);


    ED_t = [ED_Y_t; ED_Bdot_t; ED_L_t]; % direct market clearing
end
