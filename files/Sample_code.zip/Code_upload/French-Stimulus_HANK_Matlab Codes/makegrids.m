function grids = makegrids(par)

    % Unpack parameters
    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    
    % Make liquid asset grid
    switch bgrid_type
        case 'Linear'
            grids.b = linspace(bmin,bmax,I)';
        case 'NL_symmetric'
            grids.b = bmin+(1-real(exp((0:I-1)'*1i*pi/(I-1))))*(bmax-bmin)/2;
        case 'NL_lefts'
            grids.b = bmin+(1-real(exp((0:I-1)'*1i*pi/2/(I-1))))*(bmax-bmin);
        case 'NL_rights'
            grids.b = bmin+flip(real(exp((0:I-1)'*1i*pi/2/(I-1))))*(bmax-bmin);
        otherwise
            grids.b = linspace(bmin,bmax,I)';
    end

    [val0 idx0] = min(abs(grids.b));
    grids.b(idx0) = 0; % make sure one point on b is equal to zero
    
    % And illiquid asset grid
    switch agrid_type
        case 'Linear'
            grids.a = linspace(amin,amax,J);
        case 'NL_symmetric'
            grids.a = amin+(1-real(exp((0:J-1)*1i*pi/(J-1))))*(amax-amin)/2;
        case 'NL_lefts'
            grids.a = amin+(1-real(exp((0:J-1)*1i*pi/2/(J-1))))*(amax-amin);
        case 'NL_rights'
            grids.a = amin+flip(real(exp((0:J-1)*1i*pi/2/(J-1))))*(amax-amin);
        otherwise
            grids.a = linspace(amin,amax,J);
    end

    % Combined grids
    [grids.aaa, grids.bbb, grids.zzz] = meshgrid(grids.a,grids.b,z);

    % Time grid

    switch tgrid_type
        case 'Linear'
            time = 2020.25+linspace(0,Tend,N)';
        case 'NL_symmetric'
            time = 2020.25+(1-real(exp((0:N-1)'*1i*pi/(N-1))))*Tend/2;
        case 'NL_lefts'
            time = 2020.25+(1-real(exp((0:N-1)'*1i*pi/2/(N-1))))*Tend;
        case 'NL_rights'
            time = 2020.25+flip(real(exp((0:N-1)'*1i*pi/2/(N-1))))*Tend;
        case 'Custom'
            time = 2020.25+[0:1/4:3.25,4.25,5.25+(1-real(exp((0:N-16-1)*1i*pi/2/(N-16-1))))*(Tend-5.25),max(Tend,100)]'; % quarterly from 2020q2 to 2023q4, then yearly 2024-2025
            time = 2020.25+[0:1/4:3.25,4.25,...
                5.25+(1-real(exp((0:N-16)*1i*pi/2/(N-16))))*(Tend-5.25)]'; % quarterly from 2020q2 to 2023q4, then yearly 2024-2025
        case 'Power'
            x = linspace(0,1,N)';
            coeff = 25; power = 15;
            xx  = x + coeff*x.^power;
            xmax = max(xx); xmin = min(xx);
            time = 2020.25+Tend/(xmax - xmin)*xx;
    end
    
    dt_F = time(2:N)-time(1:N-1); dt_F = [dt_F;dt_F(end)];
    dt_B = time(2:N)-time(1:N-1); dt_B = [dt_B(1);dt_B];
    grids.time = time;
    grids.dt_F = dt_F;
    grids.dt_B = dt_B;
    
end





