function [Z_exo, n_endFS] = calibrate_tr_fn(par, grids, sequence)

    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    cellfun(@(x) assignin('caller', x, grids.(x)), fieldnames(grids));
    
    alphas_t = repmat(alphas', N, 1);
    Z_exo.alphas_t = alphas_t;

    % 2020q2:1, 2020q3:2, 2020q4:3, 2020q1:4, 2021q2:5 ... 

    %% Lockdown shocks
    % ================================================================
    
    Z_exo.kappa_t = ones(N, 1);
    Z_exo.kappa_t = 1-0.0*exp(-3*(grids.time-2020.25));

    Z_exo.rho_t = (1-0*exp(-3*(grids.time-2020.25)))*rho;    
    Z_exo.rho_t(2) = -0.8;
    Z_exo.rho_t(3) = 0.08;
    Z_exo.rho_t(4) = 0.05;
    Z_exo.rho_t(5) = -0.0945;
    Z_exo.rho_t(6) = -0.04;
    Z_exo.rho_t(7) = -0.02;
    Z_exo.rho_t(8) = par.rho;
    Z_exo.rho_t(9) = par.rho;
    Z_exo.rho_t(10) = par.rho;
    Z_exo.rho_t(11) =  par.rho;
    Z_exo.rho_t(12) =  0;
    Z_exo.rho_t(13) =  -0.0;
    Z_exo.rho_t(14) =  -0.04;

    Z_exo.phi_t = (1+0*exp(-3*(grids.time-2020.25)))*par.phi;
    
    % Fiscal shocks
    % ================================================================
    fiscal_adjustment = 2025;
    [~, n_endFS] = min(abs(fiscal_adjustment-grids.time));

    montant1 = zeros(n_endFS,1);
    montant2 = zeros(n_endFS,1);

    montant31 = zeros(n_endFS,1);
    montant32 = zeros(n_endFS,1);
    montant33 = zeros(n_endFS,1);
    montant34 = zeros(n_endFS,1);
    montant35 = zeros(n_endFS,1);

    montant41 = zeros(n_endFS,1);
    montant42 = zeros(n_endFS,1);
    montant43 = zeros(n_endFS,1);
    montant44 = zeros(n_endFS,1);
    montant45 = zeros(n_endFS,1);

    montant51 = zeros(n_endFS,1);
    montant52 = zeros(n_endFS,1);
    montant53 = zeros(n_endFS,1);
    montant54 = zeros(n_endFS,1);
    montant55 = zeros(n_endFS,1);

    scale = par.Y/par.GDP_stationary;
    data = readtable('../empirics/canaux_panel.csv');
    montant1(1:length(data.montant_1),1) = data.montant_1*scale;
    montant2(1:length(data.montant_1),1) = data.montant_2*scale;

    montant31(1:length(data.montant_1),1) = data.montant31*scale;
    montant32(1:length(data.montant_1),1) = data.montant32*scale;
    montant33(1:length(data.montant_1),1) = data.montant33*scale;
    montant34(1:length(data.montant_1),1) = data.montant34*scale;
    montant35(1:length(data.montant_1),1) = data.montant35*scale;

    montant41(1:length(data.montant_1),1) = data.montant41*scale;
    montant42(1:length(data.montant_1),1) = data.montant42*scale;
    montant43(1:length(data.montant_1),1) = data.montant43*scale;
    montant44(1:length(data.montant_1),1) = data.montant44*scale;
    montant45(1:length(data.montant_1),1) = data.montant45*scale;

    montant51(1:length(data.montant_1),1) = data.montant51*scale;
    montant52(1:length(data.montant_1),1) = data.montant52*scale;
    montant53(1:length(data.montant_1),1) = data.montant53*scale;
    montant54(1:length(data.montant_1),1) = data.montant54*scale;
    montant55(1:length(data.montant_1),1) = data.montant55*scale;

    switch fiscal_type
        case 'StickSS'
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_y_t = repmat(varsigma_ys', N, 1);
            Z_exo.varsigma_k_t = repmat(varsigma_ks', N, 1);

            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);
            
            Z_exo.tau_t = ones(N, 1) * tau;
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.G_t = ones(N, 1) * G;
            Z_exo.kappa_t = ones(N, S) * kappa;
            Z_exo.phi_t = ones(N, 1) * phi;
            Z_exo.rho_t = ones(N, 1) * par.rho;

        case 'LabourShock'
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_y_t = repmat(varsigma_ys', N, 1);
            Z_exo.varsigma_k_t = repmat(varsigma_ks', N, 1);
            
            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);

            Z_exo.tau_t = ones(N, 1) * tau;
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.G_t = ones(N, 1) * G;
            Z_exo.kappa_t = ones(N, S) * kappa;
            Z_exo.phi_t = ones(N, 1) * phi;
            
        case 'Baseline'
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_y_t = repmat(varsigma_ys', N, 1);
            Z_exo.varsigma_k_t = repmat(varsigma_ks', N, 1);
            
            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);
            
            Z_exo.tau_t = ones(N, 1) * tau;
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.G_t = ones(N, 1) * G;

        case 'FranceRelance'

            % Government expenditures
            Z_exo.G_t = ones(N, 1) * G;
            Z_exo.G_t(1:n_endFS) = Z_exo.G_t(1:n_endFS) + montant1;

            % Transfers to households
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.T_t(1:n_endFS) = Z_exo.T_t(1:n_endFS) + montant2;

            % Wage subsidy
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_l_t(1:n_endFS, 1) = montant31 ./ (montant31+par.Ls(1)*par.w);
            Z_exo.varsigma_l_t(1:n_endFS, 2) = montant32 ./ (montant32+par.Ls(2)*par.w);
            Z_exo.varsigma_l_t(1:n_endFS, 3) = montant33 ./ (montant33+par.Ls(3)*par.w);
            Z_exo.varsigma_l_t(1:n_endFS, 4) = montant34 ./ (montant34+par.Ls(4)*par.w);
            Z_exo.varsigma_l_t(1:n_endFS, 5) = montant35 ./ (montant35+par.Ls(5)*par.w);

            % Capital income subsidy
            Z_exo.varsigma_k_t = repmat(varsigma_ks', N, 1);
            Z_exo.varsigma_k_t(1:n_endFS, 1) = montant41 ./ (montant41+par.Ks(1)*(par.ra+par.depreciation));
            Z_exo.varsigma_k_t(1:n_endFS, 2) = montant42 ./ (montant42+par.Ks(2)*(par.ra+par.depreciation));
            Z_exo.varsigma_k_t(1:n_endFS, 3) = montant43 ./ (montant43+par.Ks(3)*(par.ra+par.depreciation));
            Z_exo.varsigma_k_t(1:n_endFS, 4) = montant44 ./ (montant44+par.Ks(4)*(par.ra+par.depreciation));
            Z_exo.varsigma_k_t(1:n_endFS, 5) = montant45 ./ (montant45+par.Ks(5)*(par.ra+par.depreciation));

            % Production tax
            Z_exo.varsigma_y_t = repmat(varsigma_ys', N, 1);
            Z_exo.varsigma_y_t(1:n_endFS, 1) = Z_exo.varsigma_y_t(1:n_endFS, 1) - (montant51 /par.Ys(1)/par.Ps(1));
            Z_exo.varsigma_y_t(1:n_endFS, 2) = Z_exo.varsigma_y_t(1:n_endFS, 2) - (montant52 /par.Ys(2)/par.Ps(2));
            Z_exo.varsigma_y_t(1:n_endFS, 3) = Z_exo.varsigma_y_t(1:n_endFS, 3) - (montant53 /par.Ys(3)/par.Ps(3));
            Z_exo.varsigma_y_t(1:n_endFS, 4) = Z_exo.varsigma_y_t(1:n_endFS, 4) - (montant54 /par.Ys(4)/par.Ps(4));
            Z_exo.varsigma_y_t(1:n_endFS, 5) = Z_exo.varsigma_y_t(1:n_endFS, 5) - (montant55 /par.Ys(5)/par.Ps(5));

            % Income tax - stays the same during discretion
            Z_exo.tau_t = ones(N, 1) * tau;
            
            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);

        case 'Decomposition'


            % Government expenditures
            Z_exo.G_t = ones(N, 1) * G;
            Z_exo.G_t(1:n_endFS) = Z_exo.G_t(1:n_endFS) + montant1*GON;

            % Transfers to households
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.T_t(1:n_endFS) = Z_exo.T_t(1:n_endFS) + montant2*TON;

            % Wage subsidy
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_l_t = repmat(varsigma_ls', N, 1);
            Z_exo.varsigma_l_t(1:n_endFS, 1) = montant31 ./ (montant31+par.Ls(1)*par.w)*varsigma_lON;
            Z_exo.varsigma_l_t(1:n_endFS, 2) = montant32 ./ (montant32+par.Ls(2)*par.w)*varsigma_lON;
            Z_exo.varsigma_l_t(1:n_endFS, 3) = montant33 ./ (montant33+par.Ls(3)*par.w)*varsigma_lON;
            Z_exo.varsigma_l_t(1:n_endFS, 4) = montant34 ./ (montant34+par.Ls(4)*par.w)*varsigma_lON;
            Z_exo.varsigma_l_t(1:n_endFS, 5) = montant35 ./ (montant35+par.Ls(5)*par.w)*varsigma_lON;

            % Capital income subsidy
            Z_exo.varsigma_k_t = repmat(varsigma_ks', N, 1);
            Z_exo.varsigma_k_t(1:n_endFS, 1) = montant41 ./ (montant41+par.Ks(1)*(par.ra+par.depreciation))*varsigma_kON;
            Z_exo.varsigma_k_t(1:n_endFS, 2) = montant42 ./ (montant42+par.Ks(2)*(par.ra+par.depreciation))*varsigma_kON;
            Z_exo.varsigma_k_t(1:n_endFS, 3) = montant43 ./ (montant43+par.Ks(3)*(par.ra+par.depreciation))*varsigma_kON;
            Z_exo.varsigma_k_t(1:n_endFS, 4) = montant44 ./ (montant44+par.Ks(4)*(par.ra+par.depreciation))*varsigma_kON;
            Z_exo.varsigma_k_t(1:n_endFS, 5) = montant45 ./ (montant45+par.Ks(5)*(par.ra+par.depreciation))*varsigma_kON;

            % Production tax
            Z_exo.varsigma_y_t = repmat(varsigma_ys', N, 1);
            Z_exo.varsigma_y_t(1:n_endFS, 1) = Z_exo.varsigma_y_t(1:n_endFS, 1) - (montant51 /par.Ys(1)/par.Ps(1))*varsigma_yON;
            Z_exo.varsigma_y_t(1:n_endFS, 2) = Z_exo.varsigma_y_t(1:n_endFS, 2) - (montant52 /par.Ys(2)/par.Ps(2))*varsigma_yON;
            Z_exo.varsigma_y_t(1:n_endFS, 3) = Z_exo.varsigma_y_t(1:n_endFS, 3) - (montant53 /par.Ys(3)/par.Ps(3))*varsigma_yON;
            Z_exo.varsigma_y_t(1:n_endFS, 4) = Z_exo.varsigma_y_t(1:n_endFS, 4) - (montant54 /par.Ys(4)/par.Ps(4))*varsigma_yON;
            Z_exo.varsigma_y_t(1:n_endFS, 5) = Z_exo.varsigma_y_t(1:n_endFS, 5) - (montant55 /par.Ys(5)/par.Ps(5))*varsigma_yON;

            % Income tax - stays the same during discretion
            Z_exo.tau_t = ones(N, 1) * tau;
            
            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);

        case 'RelanceAlt'
            
            % Government expenditures
            Z_exo.G_t = ones(N, 1) * G;
            Z_exo.G_t(1) = Z_exo.G_t(1) + sum(montant1);

            % Transfers to households
            Z_exo.T_t = ones(N, 1) * T;
            Z_exo.T_t(1) = Z_exo.T_t(1) + sum(montant2);

            % Wage subsidy
            Z_exo.varsigma_l_t = ones(N, 1) * varsigma_l;
            Z_exo.varsigma_l_t(1) = Z_exo.varsigma_l_t(1) + sum(montant3./sequence.L_t(1:n_endFS));
            
            % Capital income subsidy
            Z_exo.varsigma_k_t = ones(N, 1) * varsigma_k;
            Z_exo.varsigma_k_t(1) = Z_exo.varsigma_k_t(1) + sum(montant4./sequence.Kprod_t(1:n_endFS));

            % Production tax
            Z_exo.varsigma_y_t = ones(N, 1) * varsigma_y;
            Z_exo.varsigma_y_t(1) = Z_exo.varsigma_y_t(1) - sum(montant5./sequence.Y_t(1:n_endFS));
                        
            % Income tax - stays the same during discretion
            Z_exo.tau_t = ones(N, 1) * tau;

            % will be used by firm block in computing sectoral
            % capital-labour ratios
            Z_exo.zetas_t = alphas_t./(1-alphas_t)...
        .* (1+ Z_exo.varsigma_k_t) ./ (1+ Z_exo.varsigma_l_t);

    end

end