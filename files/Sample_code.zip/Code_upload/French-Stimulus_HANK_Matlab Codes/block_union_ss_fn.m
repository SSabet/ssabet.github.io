function L_new = block_union_ss_fn(w, C, par)
    L_new = ((par.varepsilon-1)/par.varepsilon*C^(-par.gamma)*(1-par.tau)*w/par.phi)^(1/par.frisch);
end

