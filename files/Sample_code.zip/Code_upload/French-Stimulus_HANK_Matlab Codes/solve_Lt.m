% This function backs out the path of labour supply from the wage Phillips curve of the union block
function L_new_t = solve_Lt(pi_w_t, pi_w_dot_t, w_t, C_t, tau_t, phi_t, par)
    
    L_new_t = 0*w_t;
    
    switch par.use_adhoc_PC
        case 'ad-hoc-old'
           %% Adrian old code: with the last term modified

            PC_spread = (par.varepsilon-1)/par.varepsilon.*(1-tau_t).*w_t.*C_t.^(-par.gamma) - (pi_w_dot_t-par.rho*pi_w_t)/par.PCcoeff;
            PC_penalty = (PC_spread<0);
            PC_spread = max(real(PC_spread),10e-8);

            L_new_t = (1/par.phi.*(PC_spread)).^(1/par.frisch);

            if sum(PC_penalty)>0
                disp('Issue in PC')
            end

        case 'ad-hoc'
            
            PC_spread = (par.varepsilon-1)/par.varepsilon.*(1-tau_t).*w_t.*C_t.^(-par.gamma) - par.psi*w_t.*(pi_w_dot_t-par.rho*pi_w_t)/par.varepsilon;
            L_new_t = (1/par.phi.*(PC_spread)).^(1/par.frisch);
        case 'linear'
            
            C1 = (par.varepsilon-1)*(1-par.tau)*par.L*(par.C)^(-par.gamma);
            C2 = -(par.varepsilon-1)*par.C^(-par.gamma)*par.L*par.w;
            C3 = -par.gamma*par.varepsilon*par.phi*par.L^(par.frisch+1)/par.C;
            C4 = -par.varepsilon*par.L^(1+par.frisch);
            C5 = par.frisch*par.varepsilon*par.phi*(par.L)^par.frisch;

            psi = 1/par.PCcoeff*C5;
            L_new_t = par.L + (C1*(w_t-par.w)+C2*(tau_t-par.tau) + ...
                C3*(C_t-par.C)+C4*(phi_t-par.phi)+psi*(par.rho*pi_w_t-pi_w_dot_t))/C5;

        case 'quadratic'
            c1 = par.phi * par.varepsilon;
            c2_t = ((1-par.varepsilon) .* (1-tau_t) .* C_t.^(-par.gamma)).*w_t;
            c3_t = par.psi .* (pi_w_dot_t - par.rho * pi_w_t).*w_t;
            
            B2 = c1*(1+par.frisch)*(par.L^par.frisch) + c2_t;
            A1 = c1*par.frisch*(1+par.frisch)*par.L^(par.frisch-1)/2;
            
            for t=1:par.N
                quad_coefs = [A1; B2(t); c3_t(t)];
                dL_roots = roots(quad_coefs);
                if norm(imag(dL_roots)) > 0
                    L_new_t(t) = par.L - B2(t)/A1/2; % no real root dL: choose the argmin_N
                else
                    L_roots = par.L + dL_roots;
                    pos_roots = L_roots(L_roots > 0);
                    if ~isempty(pos_roots)
                        L_new_t(t) = min(pos_roots);
                    else
                        L_new_t(t) = par.L - B2(t)/A1/2; % no positive root L_new: choose the argmin_N
                    end
                end
            end

        case 'non-linear'    %% Soroush formula: non-linear micro-founded    
            c1 = par.phi * par.varepsilon;
            c2_t = ((1-par.varepsilon) .* (1-tau_t) .* C_t.^(-par.gamma)).*w_t;
            c3_t = par.psi .* (pi_w_dot_t - par.rho * pi_w_t).*w_t;
        
            for t = 1:par.N
                c2 = c2_t(t);
                c3 = c3_t(t);
        
                PCfun =  @(N) c1*N^(1+par.frisch) + c2*N + c3;
                if c3==0
                    L_new_t(t) = (-c2/c1)^(1/par.frisch);
                else
                    lb = 0;
                    Lstar = (-c2/(c1*(1+par.frisch)))^(1/par.frisch);
                    if c3 < 0
                        ub = 100;
                    else
                        ub = Lstar;
                    end
        
                    try
                        L_new_t(t) = fzero(PCfun, [lb, ub]);
                    catch
                        L_new_t(t) = PCfun(Lstar);
                        disp('Issue in PC')
                    end
                end
            end                        
    end

end
