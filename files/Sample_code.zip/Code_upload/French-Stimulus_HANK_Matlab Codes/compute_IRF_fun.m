function [Y_t,Bg_t,Bgdot_t,tau_t,Ah_new_t,Kprod_t, Bh_new_t, C_t, w_t, L_new_t, L_t, rb_t,...
    ra_t, PD_t, g_t, A_t, pi_t,pi_pa_t, I_t, Jacob_new,CapInc_Gini_t,G_t,Netexp,Fric_t,V,Ys_t,Ks_t,Ls_t] = compute_IRF_fun(par,grids,X,Z_exo, Jacob_ED, solver_params)

    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));

    % Economic Dynamics Jacobian at Transition
    ED_tr = @(X) ED_jac_tr(X, Z_exo, par, grids);

    % switch solver_type
    switch solver_params.type
      case 'built-in'
        % Solving with built-in fsolve
        tic;
        options = optimset('MaxIter', solver_params.maxit, 'Display', 'iter', 'Algorithm', 'levenberg-marquardt', 'TolFun', solver_params.atol, 'TolX', 1e-6);

        [xjac_tr, ~, ~, ~, Jacob_new] = fsolve(ED_tr, X, options);
        f = ED_tr(xjac_tr);
        runtime = toc;

        fprintf('Convergence criterion = %f, in %f minutes. \n', sum(abs(f)), runtime / 60);
        %% Using the ss Jaocbian with own quasi-Newton
      case 'anderson'
        tic;
        if isfield(solver_params, 'atol')
            atol = solver_params.atol;
        else
            atol = 1e-9;
        end
        
        if isfield(solver_params, 'restart')
            restart = solver_params.restart;
        else
            restart = 10;
        end
        
        xtol = 1e-14;

        X0 = X;
        maxit = solver_params.maxit;
        m = solver_params.order; % Anderson mixing rank

        % building a guess using the excess demand Jacobian, use Jacobian of excess demand as starting JAcobian
        Jacob0 = Jacob_ED;

        mixing_param = solver_params.mixing; % Anderson mixing parameter

        Jacob_tr = -mixing_param*Jacob0; %default starting inverse Jacobian

        
        [xjac_tr, ~, Jacob_new] = Anderson_damped(ED_tr, X0, m, restart, maxit, Jacob_tr, atol, xtol);

        runtime = toc;

        ted_anderson = ED_tr(xjac_tr);
        

        acc = norm(ted_anderson,inf);

        fprintf('Solving transition using Anderson: accuracy %.2d, in %.2f minutes.\n', acc, runtime/60);
        
        fprintf('Convergence criterion = %f, in %f minutes. \n', sum(abs(ted_anderson)), runtime / 60);

    end

    % Get and plot output quantities
    % =====================================================================

    [Y_t, Bg_t, Bgdot_t, tau_t, Ah_new_t, Kprod_t, Bh_new_t, C_t, w_t, L_new_t,...
        L_t, rb_t, ra_t, PD_t, g_t, A_t, pi_t, Fric_t, V, Sb_t, Sa_t,Ys_t,Ks_t,Ls_t] = get_IRF(xjac_tr, Z_exo, par, grids);
    

    % % Foreign demand of bonds:
    Bf_t = block_foreign_fn(par,rb_t);

    I_t = (Sa_t - deathrate*Ah_new_t) + par.depreciation*Kprod_t;
    Bf_dot_t = Bgdot_t - (Sb_t - deathrate*Bh_new_t);

    % Net exports
    Netexp = Bf_t.*rb_t-Bf_dot_t;
    % if no net export, this should be just zero
    if norm(Bf_t,1) == 0
        Netexp = Bf_t;
    end

    % Annualized inflation

    pi_pa_t = (pi_t.*grids.dt_F+1).^(1./grids.dt_F)-1;

    % Gini for capital

    CapInc_Gini_t = zeros(N,1);
    for n=1:N
        g_a = sum(sum(g_t{n},3),1);
        
        %Gini of capital income
        yk = ra_t(n).*grids.a;
        g_yk = g_a;
        
        S_yk = cumsum(g_yk.*yk)/sum(g_yk.*yk);
        trapez_yk = (1/2)*(S_yk(1)*g_yk(1) + sum((S_yk(2:J) + S_yk(1:J-1)).*g_yk(2:J)));
        CapInc_Gini_t(n) = 1 - 2*trapez_yk;
    end

    G_t = Z_exo.G_t;

end
