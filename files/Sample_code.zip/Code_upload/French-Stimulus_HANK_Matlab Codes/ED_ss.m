function [ED, g, A] = ED_ss(agg, par, grids)

    K1 = exp(agg(1));
    L1 = exp(agg(2));
    
    rb = agg(3);
    
        
    % Firm block
    % =========================================================================
    % INPUT: L, K, varsigma_w, varsigma_w, kappa | OUTPUT: Y, ra, w
    
    [Y, ra, w, Kprod, L, Ys, Ps, Ks, Ls] = block_firms_ss_fn(K1, L1, par);
    
    % Store GE parameters
    par.w = w;
    par.L = L;
    par.rb = rb;
    par.ra = ra;
    
    rk = ra + par.depreciation;

    %' Check for variables/moments to not get out of bound (just as safety;
    % shouldn't be invoked)
    % =========================================================================
    if (L<0)
        ED = [100; 100; 1e6];
    elseif (Kprod<0)
        ED = [-1e16; 100; 100];
    elseif (Kprod/Y > 7)
        ED = [100; 100; 1e6];
    elseif (rb < -2*par.rho)
        ED = [100; 1e6; 100];
    elseif (rb > 2*(par.rho + par.deathrate))
        ED = [100; -1e6; 100];
    else
   
    % Government block
    % =========================================================================
    % INPUT: tau, varsigma_w, T, G, L | OUTPUT: Bg
    
    Bg = block_gov_ss_fn(w, rk, Ls, Ks, Ys, Ps, rb, par);
    
    % Household block
    % =========================================================================
    % INPUT: rb, ra, w, T, L | OUTPUT: Bh_new, Ah_new, C
    [Ah_new, Bh_new, C, CHI, g, A, Sb] = block_hh_ss_fn(ra, rb, w, L, par, grids);
    
    % Union block
    % =========================================================================
    % INPUT: w, tau, C | OUTPUT: L_new
    L_new = block_union_ss_fn(w, C, par);

    % Foreign supply of bonds
    % =========================================================================

    Bf = block_foreign_fn(par,rb);

    % Excess demand
    % =========================================================================
    ED_A = (Kprod-Ah_new)/Kprod;
    ED_B = (Bg-(Bh_new+Bf))/Bg;
    ED_L = (L-L_new)/L;
    
    ED = [ED_A;ED_B;ED_L];
    end
end







