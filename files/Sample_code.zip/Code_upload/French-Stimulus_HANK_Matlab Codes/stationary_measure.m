function g = stationary_measure(A, par)

    % Unpack parameter values
    I = par.I; J = par.J; K = par.K; 
    M = I*J*K;
    deathrate = par.deathrate;    

    % Fix one value so matrix isn't singular:
    vec        = zeros(M,1);
    iFix       = I-1;
    vec(iFix)  = 1e-8;
    AT         = A';
    
    if deathrate == 0
        AT(iFix,:) = [zeros(1,iFix-1),1,zeros(1,M-iFix)];
    
        % Solve system & rebase
        g_stacked = AT\vec;
        g_stacked = (g_stacked/sum(g_stacked));
        g = reshape(g_stacked,I,J,K);
    else
        % solve for measure with death and newborns
        g_stacked = (AT - deathrate*speye(M, M))\(-deathrate*par.g_newborn);
        
        if sum(g_stacked < 0) > 0
            g_stacked = max(g_stacked, 0);
        end

        g_stacked = (g_stacked/sum(g_stacked));
        g = reshape(g_stacked,I,J,K);
    end

end
