% This code minimizes the distance between model and data moments

clc
clear 
close all

% Targets
var_0_data = 0.14;
var_2_data = 0.17;
kurtosis_2_data = 2.9;
moments_data = [var_0_data, var_2_data, kurtosis_2_data];

%% Define initial guess for X (beta, lambda, sig2) and objective function

% sequence space Original initial guesses 

% Ben wise
initial_X=[0.03,0.035,0.9];

% Define the objective function as a handle to pass into fmincon

%sequence space (Ben)
objective_function = @(X) calib_calculate_distance_BenWise_fn(X, moments_data); 


%% Minimize distance, use multistart to fight local min

% Define lower bounds and upper bounds
lb = [0, 0, 0];   % Lower bounds: beta >= 0, lambda >= 0, sig2 >= 0
ub = [1, 3, 5];   % Upper bounds

% Set options for fmincon
options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');


% Generate a new initial guess slightly perturbed from the original guess
perturbed_X = initial_X + 0.1 * abs(randn(1, 3)); % Adding small random noise to each parameter

% Create optimization problem for the perturbed initial guess
problem = createOptimProblem('fmincon', 'objective', objective_function, ...
                                 'x0', initial_X, 'lb', lb, 'ub', ub, 'options', options);

% Use fmincon to find the optimal solution starting from perturbed initial guess
ms = MultiStart;
[param_opt, fval] = run(ms, problem, 10); % Run MultiStart with 20 trial points


disp('Optimal Parameters:');
disp(param_opt);
disp('Objective Function Value:');
disp(fval);


%% OPTIMAL GRID

[~, output2, output3, output4] = calib_calculate_distance_BenWise_fn(param_opt, moments_data);
Moments_model = [output2, output3, output4];

objective_function = @(X) calib_discretize_process_fn(X,param_opt,Moments_model); 

% Set options for fmincon

% Define lower bounds and upper bounds
lb = 0.5;   % Lower bounds: beta >= 0, lambda >= 0, sig2 >= 0
ub = 5;   % Upper bounds

initial_X = 2;

options = optimoptions('fmincon', 'Display', 'iter', 'Algorithm', 'sqp');

% Create optimization problem for the perturbed initial guess
problem = createOptimProblem('fmincon', 'objective', objective_function, ...
                             'x0', initial_X, 'lb', lb, 'ub', ub, 'options', options);

[optimal_X, optimal_value, exitflag, output] = fmincon(problem);


%% GET FINAL GRID

% Parameters
beta_y = param_opt(1);
lambda_y = param_opt(2);
sigma_y = param_opt(3);

K = 7; % Number of states
states = linspace(-sigma_y, sigma_y, K)*optimal_X; % Define state space
delta = states(2) - states(1); % Assuming uniform grid spacing

% Transition rate matrix
la_mat = zeros(K, K);

% Drift term (mean-reversion)
drift = -beta_y * states/delta;

% Adding the mean-reversion term
for i = 2:K-1
    la_mat(i, i+1) = max(0, drift(i));  % Transition to left state
    la_mat(i, i-1) = max(0, -drift(i)); % Transition to right state
end

% Boundary conditions
la_mat(1, 2) = max(0, -drift(1)); % Transition from first to second state
la_mat(K, K-1) = max(0, drift(K)); % Transition from last to second last state

% Correcting diagonal to ensure rows sum to zero
for i = 1:K
    la_mat(i, i) = -sum(la_mat(i, :));
end

la_row = lambda_y * normpdf(states, 0, sigma_y)/sum(normpdf(states, 0, sigma_y));
la_jump = repmat(la_row,K,1);

% Incorporating jump terms into the transition matrix
la_mat = la_mat + la_jump - diag(sum(la_jump,2));

z = exp(states);
%Adjust so mean income = 1
[weights,~] = eigs(la_mat',1,'lr');
z = z.*(sum(weights)/(z*weights));
g_z = weights/sum(weights);
plot(z,g_z)


%% SAVE

calib.g_z = g_z;
calib.la_mat = la_mat;
calib.K = K;
calib.z = z;

save('calibration.mat','calib')






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% This code minimizes the distance between model and data moments: US

% GET FINAL GRID

% Parameters
beta_y = 0.0390*4;
lambda_y = 0.0346*4;
sigma_y = 0.814;

K = 7; % Number of states
states = linspace(-sigma_y, sigma_y, K)*3.5; % Define state space
delta = states(2) - states(1); % Assuming uniform grid spacing

% Transition rate matrix
la_mat = zeros(K, K);

% Drift term (mean-reversion)
drift = -beta_y * states/delta;

% Adding the mean-reversion term
for i = 2:K-1
    la_mat(i, i+1) = max(0, drift(i));  % Transition to left state
    la_mat(i, i-1) = max(0, -drift(i)); % Transition to right state
end

% Boundary conditions
la_mat(1, 2) = max(0, -drift(1)); % Transition from first to second state
la_mat(K, K-1) = max(0, drift(K)); % Transition from last to second last state

% Correcting diagonal to ensure rows sum to zero
for i = 1:K
    la_mat(i, i) = -sum(la_mat(i, :));
end

la_row = lambda_y * normpdf(states, 0, sigma_y)/sum(normpdf(states, 0, sigma_y));
la_jump = repmat(la_row,K,1);

% Incorporating jump terms into the transition matrix
la_mat = la_mat + la_jump - diag(sum(la_jump,2));

z = exp(states);
%Adjust so mean income = 1
[weights,~] = eigs(la_mat',1,'lr');
z = z.*(sum(weights)/(z*weights));
g_z = weights/sum(weights);
plot(z,g_z)


% SAVE

calib.g_z = g_z;
calib.la_mat = la_mat;
calib.K = K;
calib.z = z;

save('calibration_US.mat','calib')