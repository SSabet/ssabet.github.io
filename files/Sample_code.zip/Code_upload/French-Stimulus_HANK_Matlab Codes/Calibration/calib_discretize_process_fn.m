function [distance,var_log_z,var_log_z_diff_two_years,kurtosis_log_z_diff_two_years]  = calib_discretize_process_fn(size,zpar,moments)

    rng(1997);
    % Parameters
    beta_y = zpar(1);
    lambda_y = zpar(2);
    sigma_y = zpar(3);

    K = 7; % Number of states
    states = linspace(-sigma_y, sigma_y, K)*size; % Define state space
    delta = states(2) - states(1); % Assuming uniform grid spacing
    
    % Transition rate matrix
    la_mat = zeros(K, K);
    
    % Drift term (mean-reversion)
    drift = -beta_y * states/delta;
    
    % Adding the mean-reversion term
    for i = 2:K-1
        la_mat(i, i+1) = max(0, drift(i));  % Transition to left state
        la_mat(i, i-1) = max(0, -drift(i)); % Transition to right state
    end
    
    % Boundary conditions
    la_mat(1, 2) = max(0, -drift(1)); % Transition from first to second state
    la_mat(K, K-1) = max(0, drift(K)); % Transition from last to second last state
    
    % Correcting diagonal to ensure rows sum to zero
    for i = 1:K
        la_mat(i, i) = -sum(la_mat(i, :));
    end

    la_row = lambda_y * normpdf(states, 0, sigma_y)/sum(normpdf(states, 0, sigma_y));
    la_jump = repmat(la_row,K,1);


    % Incorporating jump terms into the transition matrix
    la_mat = la_mat + la_jump - diag(sum(la_jump,2));
    
    z = exp(states);
    %Adjust so mean income = 1
    [weights,~] = eigs(la_mat',1,'lr');
    z = z.*(sum(weights)/(z*weights));
    g_z = weights/sum(weights);

    
    
    % Simulation of the process
    Nsim = 5000001; % Number of time steps
    dt = 0.25; % Time step size
    
    % Initial state
    [val current_state] = min(abs(states+sigma_y*0)); % Random initial state
    
    % Simulate the Markov process
    state_simulation = zeros(Nsim, 1); % Store states
    time_simulation = zeros(Nsim, 1);  % Store transition times
    
    disc_mat = expm(la_mat*dt); % discretize

    
    for t = 1:Nsim
        % Store the current state
        state_simulation(t) = current_state;
        
        % Determine the next state
        prob_vec = disc_mat(current_state, :); % Transition probabilities
        
        % Transition to the next state
        current_state = find(rand < cumsum(prob_vec), 1); % Sample next state
    end
    
    % Simulated z-values corresponding to the states
    z_simulation = exp(states(state_simulation));
    
    
    % Moments

    steps_per_year = 1/dt; % Nombre de pas par année
    T_years = 2; % Période de 2 ans
    steps_in_two_years = T_years * steps_per_year; % Pas pour deux ans
    
    
    %% Aggeragation 
    
    % Steps in one year 
    year_steps=floor(1/dt);
    
    %Simulation length in yeras
    Length = floor((Nsim)/year_steps);
    
    % Sum the values in each year 
    z_simul_matrix=reshape(z_simulation(1:Length*floor(1.0/dt)),floor(1.0/dt),Length);
    z_simulation=sum(z_simul_matrix);
     z_simulation=z_simulation(end-20000:end);
    
     %% Moments

    log_z_simulation = log(z_simulation);
    var_log_z = var(log_z_simulation);
    %fprintf('Variance (lag 0) : %.4f\n', var_log_z);
    
    % Calcul du changement logarithmique de z sur deux ans
    log_z_diff_two_years = log_z_simulation(3:end) - log_z_simulation(1:end-2);
    var_log_z_diff_two_years = var(log_z_diff_two_years);
    %fprintf('Variance (lag 2): %.4f\n', var_log_z_diff_two_years);
    
    % Calcul du kurtosis du changement logarithmique de z sur deux ans
    kurtosis_log_z_diff_two_years = kurtosis(log_z_diff_two_years);
    %fprintf('Kurtosis (lag 2) : %.4f\n\n', kurtosis_log_z_diff_two_years);

    %Compute distance
    
    distance = ((var_log_z-moments(1))/moments(1))^2+...
        ((var_log_z_diff_two_years-moments(2))/moments(2))^2+...
        ((kurtosis_log_z_diff_two_years-moments(3))/moments(3))^2;
       
end