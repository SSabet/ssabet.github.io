function [distance,var_model,var_2model,kurtosis_2_model] = calib_calculate_distance_BenWise_fn(X,moments_data)

%% This function calcualtes the distance in the sequnce space as Ben does it in HANK


%% Parameters
% Extract parameters from input vector X
beta = X(1);
lambda = X(2);
sig2 = X(3);
rng(1997);

% Parameters of the simulation
Simul = 5000000;
T = 20; % in years
N = 80; % number of gridpoints for time
dt = T / N;
yt0 = 0;
interporaltionmethod = 'linear';

% arrival rate
poisson_prob = 1-exp(-lambda*dt);



% Shocks
dW = zeros(N, 1);

% Initialize simulation matrix
y_simul = zeros(Simul, 1);

%%% JUMP IS Done as BEN
Jump=binornd(1, poisson_prob, Simul, 1);
dJ = normrnd(0, sig2, Simul, 1) .* Jump;

% Run simulation
for j = 1:Simul
        y_simul(j+1) = (1-Jump(j)).* (y_simul(j) - beta * y_simul(j) * dt)  + dJ(j);
end


%% Here we aggeragte up to year

%back to level
y_simul_level=exp(y_simul);

% Steps in one year (4 quarters)
year_steps=floor(4.0/dt);

%Simulation length in yeras
Length = floor(Simul/year_steps);

% Sum the values in each year 
y_simul_matrix=reshape(y_simul_level(1:Length*floor(4.0/dt)),floor(4.0/dt),Length);
y_simul=sum(y_simul_matrix);

% back to logs
y_simul=log(y_simul);


%% Cacluate 2 year differences
% 2 year differences
Delta_2 = y_simul(3:end)-y_simul(1:end-2);
% 


% Model moments
% Level vs 2 year changes
Level_income=y_simul(end-20000:end);
Level_income= Level_income(:);
Delta_2_income=Delta_2(end-20000:end);
Delta_2_income=Delta_2_income(:);


% % Model moments 
var_model=var(Level_income(:));
var_2model=var(Delta_2_income(:));
kurtosis_2_model=kurtosis(Delta_2_income(:));

% distance as Ben 
distance=100*(((var_model-moments_data(1))/moments_data(1))^2+((var_2model-moments_data(2))/moments_data(2))^2+((kurtosis_2_model-moments_data(3))/moments_data(3))^2);

end
