% author: Soroush Sabet
% Sources:
% "Two Classes of Multisecant Methods for Nonlinear Acceleration" (Fang & Saad, 2009)
% "Globally Convergent Type-I Anderson Acceleration for Non-Smooth Fixed-Point Iterations" (Zhang et. al. 2018)
% Defaults:
%   restart > 0; % apply periodic restarting with this period
% warning: experimental implementation, not optimised

function [x_best, norm_min, G_best] = Anderson_damped(F, x0, m, restart, maxit, B0, atol, xtol)

    switch nargin
      case 8
        % restart = varargin{1};
      case 7
        xtol = 1e-10;
      case 6
        atol = 1e-8;
        xtol = 1e-10;
      case 5
        B0 = -100*eye(length(x0));
        atol = 1e-8;
        xtol = 1e-10;
      case 4
        maxit = 150;
        B0 = -100*eye(length(x0));
        atol = 1e-8;
        xtol = 1e-10;
      case 3
        restart = 10;
        maxit = 150;
        B0 = -100*eye(length(x0));
        atol = 1e-8;
        xtol = 1e-10;
      case 2
        m = 1; % default: Broyden I (no Anderson mixing)
        restart = 10;
        maxit = 150;
        B0 = -100*eye(length(x0));
        atol = 1e-8;
        xtol = 1e-10;
      otherwise
        fprintf('Wrong input arguments to Anderson solver function. \n')
        return
    end
    x = x0;
    G0 = inv(B0);
    G = G0;
    fn = F(x);
    
    norm0 = norm(fn,1); % keep track of initial norm for detecting divergence
    
    norm_min = Inf; % to keep track the best guess so far
    x_best = x0;
    G_best = G;
    
    % periodic restart with a random small perturbation of x_best
    x_rest = x_best; 
    
    c1 = 1; % restarting counter

    thetabar = 0.01; % dampening treshold
    tau = 1e-8;
    phi_thet = @(eta) (abs(eta) >= thetabar) + (abs(eta) < thetabar).*(1-sign(eta+eps)*thetabar)./(1-eta);

    restart_period = restart + 1;

    for k = 1:maxit

        m_k = min(m,c1);
        
        dx = -G*fn;
        x_next = x + dx ;

        try
            f_next = F(x_next);
        catch err

            fprintf('An error was thrown by the evaluating function, resetting now. \n');           
            x = x_rest;
            fn = f_rest;
            c1 = 1;
            G = G0;

            x_rest = x_best.*(1+randn(size(x0))/1000); % to prevent a visious loop
            continue
        end

        df = f_next - fn;

        norm_f = norm(f_next,1);
        norm_s = norm(dx);

        if norm_f < norm_min
            x_best = x_next;
            x_rest = x_best;
            f_rest = f_next;
            norm_min = norm_f;
            G_best = G;
        end
       
        % recursively building auxiliary matrices for rank-k_m update of G
        % hat objects for Powell regularisation
        if (m_k == 1)
            Xn = dx;
            Fn = df;
            dx_hat = dx;

            Xn_hat = dx;
            eta_n = dx'*G*df/(dx'*dx);
            theta_n = phi_thet(eta_n);
            Fn_tild = theta_n*df + (1-theta_n)*(G\dx);
        elseif (size(Xn, 2) < m_k)
            dx_hat = dx - Xn_hat*((Xn_hat'*Xn_hat)\Xn_hat'*dx);
            Xn = [Xn, dx];
            Fn = [Fn, df];

            Xn_hat = [Xn_hat, dx_hat];

            eta_n = dx_hat'*G*df/(dx_hat'*dx_hat);
            theta_n = phi_thet(eta_n);
            df_tild = theta_n*df + (1-theta_n)*(G\dx);

            Fn_tild = [Fn_tild, df_tild];
        else
            Xn_hat = Xn_hat(:,2:end);
            dx_hat = dx - Xn_hat*((Xn_hat'*Xn_hat)\Xn_hat'*dx);
            
            Xn = [Xn(:,2:end), dx];
            Fn = [Fn(:,2:end), df];

            Xn_hat = [Xn_hat, dx_hat];
            eta_n = dx_hat'*G*df/(dx_hat'*dx_hat);
            theta_n = phi_thet(eta_n);
            df_tild = theta_n*df + (1-theta_n)*(G\dx);

            Fn_tild = [Fn_tild(:,2:end), df_tild];
        end

        % Powell-type regularisation (Zhang et. al.)
        
        % regularised update type I (corresponds to good Broyden)
        Mn = Xn_hat'*G*Fn_tild;
        NnT = Xn_hat'*G;
        VnT = Mn\NnT;
               
        G = G + (Xn- G*Fn_tild)*VnT;
        
        x = x_next;
        fn = f_next;
       
        fprintf('At iteration %i of the Anderson(%i) method, m_k is %i, norm is %f. \n', k, m, m_k, norm_f);
        c1 = c1 + 1;

        if (norm(dx_hat) < tau*norm(dx))
            fprintf('Norm dx_hat too small, restarting now. \n');
            c1 = 1;
            G = G0;
        end
        
        if (restart > 0 && mod(c1,restart_period) == 0)
                fprintf('Periodic restarting at period %i. \n', k);
                x = x_rest;
                fn = f_rest;
                c1 = 1;
                G = G0;

                x_rest = x_best.*(1+randn(size(x0))/100000); % to prevent a visious loop
                f_rest = F(x_rest);
        end
        
        if norm_f < atol
            fprintf('Anderson iteration converged. \n');
            break
        elseif norm_s < xtol
            fprintf('Step threshold hit, terminating now. \n');

           x = x_best.*(1+randn(size(x0))/100000);         
           fn = F(x);
           c1 = 1;
           G = G0;
        elseif norm_f > 1e10*norm0 || isnan(norm_f)
            fprintf('Anderson is diverging, terminating now, try changing the starting guess. \n');
           x = x_best.*(1+randn(size(x0))/1000);
           fn = F(x);
           c1 = 1;
         G = G0;
        end
    end
end


