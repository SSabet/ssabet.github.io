function [C_t, Bh_new_t, Ah_new_t, g_t, fric_t, Sb_t, Sa_t] = KFE(A_t, c_t, d_t, sb_t, sa_t, par, grids)
    
    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    cellfun(@(x) assignin('caller', x, grids.(x)), fieldnames(grids));

    gg{1}=reshape(g,M,1);
    C_t = zeros(N,1);
    Sb_t = zeros(N,1);
    Sa_t = zeros(N,1);
    Bh_new_t = zeros(N,1);
    Ah_new_t = zeros(N,1);
    fric_t = zeros(N,1);
    
    for n=1:N
        AT=A_t{n}';
        % Distributino Sequence
        gg_next= ((1+deathrate*dt_F(n))*speye(M) - AT*dt_F(n))\...
            (gg{n} + deathrate*dt_F(n)*g_newborn); %implicit method
        gg_next = max(gg_next, 0);
        gg{n+1} = gg_next/(sum(gg_next));

        g_t{n} = reshape(gg{n},I,J,K);
        C_t(n) = sum(g_t{n}(:).*c_t{n}(:));
        Sb_t(n) = sum(g_t{n}(:).*sb_t{n}(:));
        Sa_t(n) = sum(g_t{n}(:).*sa_t{n}(:));
        Bh_new_t(n) = sum(g_t{n}(:).*grids.bbb(:));
        Ah_new_t(n) = sum(g_t{n}(:).*grids.aaa(:));
        mass_t(n) = sum(g_t{n}(:));

        % Frictions
        cchi = two_asset_kinked_cost(d_t{n}, grids.aaa, chi0, chi1);
        CHI = sum(cchi(:).*g_t{n}(:));
        kkappa = -spread*grids.bbb.*(grids.bbb<0);
        KAPPA = sum(kkappa(:).*g_t{n}(:));
        fric_t(n) = CHI + KAPPA;
    end

end

