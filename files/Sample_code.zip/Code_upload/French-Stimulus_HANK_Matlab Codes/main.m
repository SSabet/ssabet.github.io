% Parameters and grids
clearvars -except x_ss; close all; clc
% -------------------------------------------------------------------------

% -------------------------------------------------------------------------
% Read parameters

par = parameters;
cellfun(@(x) assignin('base', x, par.(x)), fieldnames(par));
par.US_calib=0;
% -------------------------------------------------------------------------
% Prepare endogenous state grids

grids =  makegrids(par);
cellfun(@(x) assignin('base', x, grids.(x)), fieldnames(grids));

par.time = time;
% ==================================================================
% STEADY STATE
% ==================================================================
% defining he excess demand function
ED_ss_fun = @(agg) ED_ss(agg,par,grids);

% initial guess of values for parameters
K1 = log(42*par.omegas(1));
L1 = log(7*par.omegas(1));
rb = 0.04;

x = [K1; L1; rb];


%' solving for the steady state (SS) by zeroing the excess demands in the
% three markets, using the Levenberg-Marquardt algorithm
tic;
options = optimset('MaxIter', 20, 'Display', 'iter', 'Algorithm', 'levenberg-marquardt', 'TolFun', 1e-10, 'TolX', 1e-12);
x_ss = fsolve(ED_ss_fun, x, options);
[f, g, A] = ED_ss_fun(x_ss);
rntime = toc;

K1 =  exp(x_ss(1));
L1 = exp(x_ss(2));
rb = x_ss(3);

clc;
fprintf('Convergence criterion = %f, obtained in %f seconds. K1 = %f, L1 = %f and rb = %f. \n' ,sum(abs(f)), rntime, K1, L1, rb);

% =========================================================================
% CHECK STAY DY STATES QUANTITIES AND STORE THEM
% =========================================================================

[par.ra,par.rb, par.L, par.Kprod ,par.w,par.g,par.vNew,par.Bg,par.Y, par.C,...
    par.Chi, par.g_newborn,par.Ys, par.Ps, par.Ls, par.Ks] = get_ss(x_ss,par,grids);


%% ==================================================================
% TRANSITION
% ==================================================================

fprintf('Checking the transition absent shocks.\n');

% Parameters setup
par.fiscal_type = 'StickSS';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,0);

% Steady-state sequences
X = [ones(N, 1) * log(K1); ones(N, 1) * log(L1); ones(N, 1) * rb];

%' Define the trajectories of the excess demands in three markets function
% over the transition path
ED_tr = @(X) ED_jac_tr(X, Z_exo, par, grids);

% Options for fsolve
options = optimset('MaxIter', 0, 'Display', 'iter', 'Algorithm', 'levenberg-marquardt', ...
    'TolFun', 1e-6, 'TolX', 1e-6);

%' Check the excess demand trajectories over the transition path; compute
% the SS sequence space Jacobian of transition excess demand using fsolve;
% check the condition number of the sequence space Jacobian at the SS 
fprintf('Computing Jacobian of Excess Demands wrt inputs using fsolve ...\n');
tic;
[X_fsolve, ED_tr_fsolve, ~, ~, Jacob_ED_fsolve] = fsolve(ED_tr, X, options);
duration = toc;

fprintf('\nDone in %.f seconds. Condition number of the Jacobian is %d.\n', duration, cond(Jacob_ED_fsolve));


%% Baseline Scenario: No Fiscal Stimulus Package
% ----------------------------------------------
fprintf('Solving for Baseline.\n');

par.fiscal_type = 'Baseline';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,0);

% Initial conditions
X = [ones(N, 1) * log(K1); ones(N, 1) * log(L1); ones(N, 1) * rb];

Jacob_ED_base = Jacob_ED_fsolve;

% solver parameters
solver_params = struct('type', 'anderson', 'mixing', 100, 'order', 2, 'maxit', 60, 'atol', 1e-4, 'restart', 10);

%' Compute IRF using the my own-implemented quasi-Newton method with 
% Anderson acceleration
[nofiscalIRF.Y_t, nofiscalIRF.Bg_t, nofiscalIRF.Bgdot_t, nofiscalIRF.tau_t, ...
 nofiscalIRF.Ah_new_t, nofiscalIRF.Kprod_t, nofiscalIRF.Bh_new_t, nofiscalIRF.C_t, ...
 nofiscalIRF.w_t, nofiscalIRF.L_new_t, nofiscalIRF.L_t, nofiscalIRF.rb_t, ...
 nofiscalIRF.ra_t, nofiscalIRF.PD_t, nofiscalIRF.g_t, nofiscalIRF.A_t, ...
 nofiscalIRF.pi_t,nofiscalIRF.pi_pa_t, nofiscalIRF.I_t, nofiscalIRF.Jacob_new, ...
 nofiscalIRF.CapInc_Gini_t,nofiscalIRF.G_t,nofiscalIRF.Netexp,nofiscalIRF.Fric_t,...
 nofiscalIRF.V,nofiscalIRF.Ys_t,nofiscalIRF.Ks_t,nofiscalIRF.Ls_t] = compute_IRF_fun(par, grids, X, Z_exo, ...
 Jacob_ED_base, solver_params);

if strcmp(solver_params.type, 'built-in')
    Jacob_ED_base = nofiscalIRF.Jacob_new;
end

% Check market clearing

ED_y = (abs((nofiscalIRF.C_t+nofiscalIRF.I_t+Z_exo.G_t ...
    + nofiscalIRF.Netexp + nofiscalIRF.Fric_t)./nofiscalIRF.Y_t-1))*100;
disp(['Market clearing:',num2str(max(ED_y)),'%'])

data = readtable('../empirics/gdp_data.csv');

figure()
hold on
plot(grids.time,nofiscalIRF.Y_t./par.Y*100-100,'LineWidth',2);
plot(grids.time(1:17),data.y_data(1:17)*100-100,'--','LineWidth',2);
plot(grids.time,nofiscalIRF.Y_t*0,':');
xlim([2020 2023.5])
legend({'Model','Data'})
xlim([2020 2023.5])


% France Relance Scenario: With Fiscal Stimulus Package
% ------------------------------------------------------
fprintf('Solving for France Relance.\n');

par.fiscal_type = 'FranceRelance';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids, nofiscalIRF);

solver_params = struct('type', 'anderson', 'mixing', 10, 'order', 2, 'maxit', 60, 'atol', 1e-5, 'restart', 10);

% Update initial conditions with nofiscalIRF results
X = [log(nofiscalIRF.Ks_t(:,1)); log(nofiscalIRF.Ls_t(:,1)); nofiscalIRF.rb_t];

% Compute IRF
[withfiscalIRF.Y_t, withfiscalIRF.Bg_t, withfiscalIRF.Bgdot_t, withfiscalIRF.tau_t, ...
 withfiscalIRF.Ah_new_t, withfiscalIRF.Kprod_t, withfiscalIRF.Bh_new_t, withfiscalIRF.C_t, ...
 withfiscalIRF.w_t, withfiscalIRF.L_new_t, withfiscalIRF.L_t, withfiscalIRF.rb_t, ...
 withfiscalIRF.ra_t, withfiscalIRF.PD_t, withfiscalIRF.g_t, withfiscalIRF.A_t, ...
 withfiscalIRF.pi_t,withfiscalIRF.pi_pa_t, withfiscalIRF.I_t, withfiscalIRF.Jacob_new, ...
 withfiscalIRF.CapInc_Gini_t,withfiscalIRF.G_t,withfiscalIRF.Netexp,withfiscalIRF.Fric_t,...
 withfiscalIRF.V,withfiscalIRF.Ys_t,withfiscalIRF.Ks_t,withfiscalIRF.Ls_t] = compute_IRF_fun(par, grids, X, Z_exo, ...
 Jacob_ED_base, solver_params);

ED_y = max(abs((withfiscalIRF.C_t+withfiscalIRF.I_t+Z_exo.G_t ...
    + withfiscalIRF.Netexp + withfiscalIRF.Fric_t)./withfiscalIRF.Y_t-1))*100;
disp(['Market clearing:',num2str(ED_y),'%'])

figure()
hold on
plot(grids.time,withfiscalIRF.Y_t./par.Y*100-100,'LineWidth',2);
plot(grids.time,withfiscalIRF.Y_t*0,':');
xlim([2020 2023.5])
legend({'Model','Data'})
xlim([2020 2023.5])


%% Decomposition of France Relance's channels
% -----------------------------------------------
fprintf('Solving for Decomposition. \n');

par.fiscal_type = 'Decomposition';

% Define the different parameter configurations
configs = {
    struct('varsigma_lON', 1, 'varsigma_yON', 0, 'varsigma_kON', 0, 'GON', 0, 'TON', 0, 'IRF_name', 'varsigma_lON_IRF'),
    struct('varsigma_lON', 0, 'varsigma_yON', 1, 'varsigma_kON', 0, 'GON', 0, 'TON', 0, 'IRF_name', 'varsigma_yON_IRF'),
    struct('varsigma_lON', 0, 'varsigma_yON', 0, 'varsigma_kON', 1, 'GON', 0, 'TON', 0, 'IRF_name', 'varsigma_kON_IRF'),
    struct('varsigma_lON', 0, 'varsigma_yON', 0, 'varsigma_kON', 0, 'GON', 1, 'TON', 0, 'IRF_name', 'GON_IRF'),
    struct('varsigma_lON', 0, 'varsigma_yON', 0, 'varsigma_kON', 0, 'GON', 0, 'TON', 1, 'IRF_name', 'TON_IRF')
};

% reduce precision a bit for higher speed

% Iterate over each configuration
for i = 1:length(configs)

    config = configs{i};
    
    % Update parameters
    par.varsigma_lON = config.varsigma_lON;
    par.varsigma_yON = config.varsigma_yON;
    par.varsigma_kON = config.varsigma_kON;
    par.GON = config.GON;
    par.TON = config.TON;
    
    % Perform calibration
    [Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids, nofiscalIRF);

    if i~=3
        solver_params = struct('type', 'anderson', 'mixing', 100, 'order', 5, 'maxit', 100, 'atol', 1e-5, 'restart', 12);
    else
        solver_params = struct('type', 'built-in', 'mixing', 100, 'order', 2, 'maxit', 7, 'atol', 1e-5);
    end
    
    % Create X vector
    X = [log(withfiscalIRF.Ks_t(:,1)); log(withfiscalIRF.Ls_t(:,1)); withfiscalIRF.rb_t];

    % Compute IRF
    IRF = struct();
    [IRF.Y_t, IRF.Bg_t, IRF.Bgdot_t, IRF.tau_t, ...
     IRF.Ah_new_t, IRF.Kprod_t, IRF.Bh_new_t, IRF.C_t, ...
     IRF.w_t, IRF.L_new_t, IRF.L_t, IRF.rb_t, ...
     IRF.ra_t, IRF.PD_t, IRF.g_t, IRF.A_t, ...
     IRF.pi_t,IRF.pi_pa_t, IRF.I_t, IRF.Jacob_new, ...
     IRF.CapInc_Gini_t,IRF.G_t,IRF.Netexp,IRF.Fric_t,...
     IRF.V,IRF.Ys_t,IRF.Ks_t,IRF.Ls_t] = compute_IRF_fun(par, grids, X, Z_exo, ...
     Jacob_ED_base, solver_params);
    
    % Assign to appropriate variable
    assignin('base', config.IRF_name, IRF);
end



%% PLOT OUTPUT

% Format the dates

% Extract the year and quarter from the vector
years = floor(grids.time)-2000;                 % Get the year part
quarters = round((grids.time - years-2000) * 4+1); % Get the quarter part (Q1, Q2, Q3, Q4)
yearQuarter = strcat(string(years), '-T', string(quarters));
year_end = 2023.5;
yearsplotted=3.5;


%% Figure 1

close; set(gcf,'Position',[100 500 600 600])
hold on
plot(grids.time,withfiscalIRF.Y_t./par.Y*100-100,'LineWidth',2,'Color',par.c1);
plot(grids.time,nofiscalIRF.Y_t./par.Y*100-100,'LineWidth',2,'Color',par.c4);
legend({'Avec France Relance','Sans France Relance'},'Box','off','Location','southeast','Interpreter', 'latex','FontSize',20);
xlim([grids.time(1) year_end]);
ylim([-21 1])
xticks(grids.time);
xticklabels(yearQuarter);
xtickangle(45);
yticks([-15,-10,-5,0]);
xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('deviation de l''\''etat stationnaire (pp)','FontSize',20,'Interpreter','Latex');
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');
print('-dpng', '-r300','../Output/contrefactuel_model.png');

close; set(gcf,'Position',[100 500 600 600])
hold on
plot(grids.time(1:17),data.y_data(1:17)*100-100,'--','LineWidth',2,'Color',[1 1 1]/2);
ylim([-21 1])
xlim([grids.time(1) year_end]);
legend({'Donnees'},'Box','off','Location','southeast','Interpreter', 'latex','FontSize',20);
xticks(grids.time);              
xticklabels(yearQuarter);  
yticks([-15,-10,-5,0]);     
xtickangle(45);    
xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('deviation de l''\''etat stationnaire (pp)','FontSize',20,'Interpreter','Latex');
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

print('-dpng', '-r300','../Output/contrefactuel_donnees.png');




%% Figure 2 GDP GAIN FROM POLICY

par.fiscal_type = 'FranceRelance';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,nofiscalIRF);

% Calculate the components for the stacked bar
output_gain = withfiscalIRF.Y_t ./ nofiscalIRF.Y_t * 100 - 100;
consumption = (withfiscalIRF.C_t - nofiscalIRF.C_t) ./ nofiscalIRF.Y_t * 100;
investment = (withfiscalIRF.I_t - nofiscalIRF.I_t) ./ nofiscalIRF.Y_t * 100;
govt_expenditure = (Z_exo.G_t - par.G) ./ nofiscalIRF.Y_t * 100;
netexp = (withfiscalIRF.Netexp - nofiscalIRF.Netexp)./ nofiscalIRF.Y_t * 100;
frictions = (withfiscalIRF.Fric_t - nofiscalIRF.Fric_t)./ nofiscalIRF.Y_t * 100;

% Combine the components into one matrix for the stacked bar
stacked_data = [consumption, investment, govt_expenditure]';

% Create the bar plot with decomposition
close; set(gcf,'Position',[100 500 1200 500])
hold on;
b = bar(grids.time, stacked_data, 'stacked');
aggregateoutput = plot(grids.time, output_gain-frictions,'-o','linewidth',2,'color',[1,1,1]/4);

b(1).FaceColor = par.c1;  % Consumption
b(2).FaceColor = par.c4;  % Investment
b(3).FaceColor = par.c2;  % Govt Expenditure

% Add legend and labels
legend({'Consommation', 'Investissement', 'D\''epense publique','Total'}, 'Box', 'off','FontSize',20,'Interpreter','Latex');
xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('Points de PIB','FontSize',20,'Interpreter','Latex');
xlim([grids.time(1)-.14 grids.time(1) + yearsplotted]);

% Format x-axis to show trimesters
xticks(grids.time);              
xticklabels(yearQuarter);
xtickangle(45);

hold off;
ax = gca; % Get current axes
ax.FontSize = 20; % Set font size of ticks
set(gca, 'TickLabelInterpreter', 'latex');
print('-dpng', '-r300','../Output/GDPgains.png');

% Average gain

av_total = mean(output_gain(1:12)-frictions(1:12));
av_c = mean(consumption(1:12));
av_i = mean(investment(1:12));
av_g = mean(govt_expenditure(1:12));

disp(['output gain = ',num2str(av_total)])

disp(['part c = ',num2str(av_c/av_total)])
disp(['part i = ',num2str(av_i/av_total)])
disp(['part g = ',num2str(av_g/av_total)])

% Multiplier

par.fiscal_type = 'FranceRelance';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,nofiscalIRF);

shock = struct();
shock.varsigma_l_t = Z_exo.varsigma_l_t - par.varsigma_ls';
shock.varsigma_k_t = Z_exo.varsigma_k_t - par.varsigma_ks';
shock.varsigma_y_t = Z_exo.varsigma_y_t - par.varsigma_ys';
shock.G_t = Z_exo.G_t - par.G;
shock.T_t = Z_exo.T_t - par.T;

cost_FR_t = sum(shock.varsigma_l_t + shock.varsigma_k_t + shock.varsigma_y_t + shock.G_t + shock.T_t,2);

n_end_multiplier = par.n_endFS;
n_end_multiplier = 18;

outputdiff = withfiscalIRF.Y_t - nofiscalIRF.Y_t;
multiplier = sum(outputdiff(1:n_end_multiplier).*dt_F(1:n_end_multiplier))...
    /sum(cost_FR_t(1:n_end_multiplier).*dt_F(1:n_end_multiplier));

disp(['multiplier est ',num2str(multiplier*100),'%'])


%% Figure 3 EMPLOYMENT GAIN FROM POLICY


% Calculate the components for employment gains
emp_gain_pct = withfiscalIRF.L_t ./ nofiscalIRF.L_t * 100 - 100; % Percentage point gains
emp_gain_jobs = emp_gain_pct / 100 * par.employment/1000; % Number of jobs (thousands)

% Create the figure
close; 
figure('Position', [100, 500, 1200, 500]);

% Left y-axis for percentage points
yyaxis left;
bar(grids.time, emp_gain_pct, 'FaceColor', par.c3, 'EdgeColor', 'none'); % Bar plot for percentage gains
ylabel('Points d''emploi (pp)', 'Interpreter', 'latex'); % Label for left y-axis
ax1 = gca; % Store current axis for formatting

% Right y-axis for number of jobs
yyaxis right;
bar(grids.time, emp_gain_jobs, 'FaceColor', par.c3, 'EdgeColor', 'none', 'FaceAlpha', 0.6); % Bar plot for job gains
ylabel('Nombre d''emplois (milliers)', 'Interpreter', 'latex'); % Label for right y-axis

% Format x-axis
xlim([grids.time(1) - 0.14, grids.time(1) + yearsplotted]);
xticks(grids.time);              
xticklabels(yearQuarter);      
xtickangle(45);


% Format both axes
ax1.FontSize = 20; % Set font size of ticks
ax1.YAxis(1).Color = [0 0 0];
ax1.YAxis(2).Color = [0 0 0];
set(gca, 'TickLabelInterpreter', 'latex'); % LaTeX formatting for tick labels

% Save the figure
print('-dpng', '-r300', '../Output/Empgains.png');

% AVERAGE EMPLOYEMENT GAIN

av_total = mean(emp_gain_jobs(1:12));
disp(['employment gain = ',num2str(av_total)])


%% Figure 4: INFLATION AND PRICE LEVEL

% inflation
year_end = 2023.5;
pi_pa_t1 = movmean([0;0;0;withfiscalIRF.pi_pa_t(1:end)],[4, 0]); pi_pa_t1 = pi_pa_t1(4:end);
pi_pa_t2 = movmean([0;0;0;nofiscalIRF.pi_pa_t(1:end)],[4, 0]); pi_pa_t2 = pi_pa_t2(4:end);
time_inf = [2020;grids.time];

close; set(gcf,'Position',[100 500 700 600])
hold on
plot(time_inf,[0;pi_pa_t1]*0, '--', 'Color', [1 1 1]/2);
plot(time_inf,[0;pi_pa_t1]*100-[0;pi_pa_t2]*100, 'LineWidth', 4, 'Color', c1);
xlim([time_inf(1) year_end]);
xticks(time_inf);              
xticklabels(['20-T1';yearQuarter]);
xtickangle(45);    
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('points de pourcentages','FontSize',20,'Interpreter','Latex');
print('-dpng', '-r300','../Output/inf_annual.png');

% Niveau des prix
P1 = exp(cumsum(log(1+withfiscalIRF.pi_pa_t.*dt_F)));
P2 = exp(cumsum(log(1+nofiscalIRF.pi_pa_t.*dt_F)));

close; set(gcf,'Position',[100 500 700 600])
hold on
plot(time_inf,[0;pi_pa_t1]*0, '--', 'Color', [1 1 1]/2);
plot(time_inf,[0;movmean(P1./P2,2)*100-100], 'LineWidth', 4, 'Color', c1);
xlim([time_inf(1) year_end]);
xticks(time_inf);              
xticklabels(['20-T1';yearQuarter]);
xtickangle(45);    
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('\%','FontSize',20,'Interpreter','Latex');
print('-dpng', '-r300','../Output/relative_price_level.png');


%% Figure 5 SECTORAL EFFECTS

output_gain_s = withfiscalIRF.Ys_t ./ nofiscalIRF.Ys_t * 100 - 100;

weights = par.Ys.*par.Ps/sum(par.Ys.*par.Ps);

contribution_s = output_gain_s.*repmat(weights',length(output_gain_s),1);

close all; set(gcf,'Position',[100 500 1200 500])

b = bar(grids.time, contribution_s,'stack');

b(1).FaceColor = [0,0,0];
b(2).FaceColor = c1;
b(3).FaceColor = c2;
b(4).FaceColor = c3;
b(5).FaceColor = c4;

legend({'Agriculture','Commerce','Construction','Industrie','Services'}, 'Box', 'off','FontSize',15,'Interpreter','Latex');
xlabel('Trimestre','FontSize',15,'Interpreter','Latex');
ylabel('Points de PIB','FontSize',15,'Interpreter','Latex');
xlim([grids.time(1)-.14 grids.time(1) + yearsplotted]);
xticks(grids.time);
xticklabels(yearQuarter);
xtickangle(45);
ylim([0 1])
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');
print('-dpng', '-r300','../Output/Sectors.png');
hold off;

% Contribution moyenne

mean(contribution_s(1:12,:))/mean(output_gain(1:12))*100


%% Figure 6: DECOMPOSING THE CHANNELS

close all
yearsplotted = 3.5;
channel = {varsigma_lON_IRF,varsigma_yON_IRF,varsigma_kON_IRF,GON_IRF,TON_IRF,withfiscalIRF};
channel_name = {'varsigma_lON_IRF','varsigma_yON_IRF','varsigma_kON_IRF','GON_IRF','TON_IRF','withfiscalIRF'};
channel_titles = {'Aide a l''emploi','R\''eduction des impots de production',...
    'Aide a l''investissement','D\''epenses gouvernementales','Transferts aux menages','Effet total'};

for i = 1:6
    par.fiscal_type = 'Decomposition';

    if i==4||i==6
        par.GON=1;
    else
        par.GON=0;
    end

    [Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,nofiscalIRF);
    
    % Calculate the components for the stacked bar
    output_gain = channel{i}.Y_t ./ nofiscalIRF.Y_t * 100 - 100;
    consumption = (channel{i}.C_t - nofiscalIRF.C_t) ./ nofiscalIRF.Y_t * 100;
    investment = (channel{i}.I_t - nofiscalIRF.I_t) ./ nofiscalIRF.Y_t * 100;
    govt_expenditure = (Z_exo.G_t - par.G) ./ nofiscalIRF.Y_t * 100;
    netexp = (channel{i}.Netexp - nofiscalIRF.Netexp)./ nofiscalIRF.Y_t * 100;
    frictions = (channel{i}.Fric_t - nofiscalIRF.Fric_t)./ nofiscalIRF.Y_t * 100;

    % Combine the components into one matrix for the stacked bar
    stacked_data = [consumption, investment, govt_expenditure]';
    
    % Create the bar plot with decomposition
    %close; 
    figure(i)
    set(gcf,'Position',[100 500 600 500])
    hold on;
    b = bar(grids.time, stacked_data, 'stacked');
    aggregateoutput = plot(grids.time, output_gain-frictions,'-o','linewidth',2,'color',[1,1,1]/4);
    
    b(1).FaceColor = c1;  % Consumption
    b(2).FaceColor = c4;  % Investment
    b(3).FaceColor = c2;  % Govt Expenditure

    % Add legend and labels
    if i==1
        legend({'Consommation', 'Investissement', 'Depense publique'}, 'Box', 'off','FontSize',22,'Interpreter','Latex');
    end
    title(channel_titles{i},'FontSize',35,'Interpreter','Latex');
    xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
    ylabel('Points de PIB','FontSize',15,'Interpreter','Latex');
    set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');
    xlim([grids.time(1)-.14 grids.time(1) + yearsplotted]);
    ylim([-0.05, .9]);
    xticks(grids.time);              
    xticklabels(yearQuarter);      
    xtickangle(45);                
    hold off;
    
    print('-dpng', '-r300',['../Output/GDPgains_',channel_name{i},'.png']);

    disp([channel_name{i},' : ',num2str(mean(output_gain(1:12)-frictions(1:12)))])

end

%% Figure 7: DISTRIBUTIONAL GAINS

% Welfare by decile of wealth
% ========================================

Ngw = 10000;
threshold_gw = linspace(bmin,amax+bmax,Ngw)';
percentiles = linspace(0,1,100)';
G_w = zeros(1,Ngw);

for iw = 1:Ngw-1
    G_w(iw) = sum(par.g(:).*(grids.aaa(:)+grids.bbb(:)<threshold_gw(iw)));

end

% Change in welfare

Npct = 11;
V_FR = zeros(1,Npct);
V_base = zeros(1,Npct);
pct = linspace(0,1,Npct)';
pct_w = interp1(G_w + threshold_gw'*10e-12,threshold_gw,pct);
pct_w(Npct) = bmax + amax;

for iw = 1:Npct-1
    %ID = abs(grids.aaa(:)+grids.bbb(:)-threshold_gw(iw))<=1;
    ID = (grids.aaa(:)+grids.bbb(:)<pct_w(iw+1)).*(grids.aaa(:)+grids.bbb(:)>=pct_w(iw));
    ID_mass = sum(par.g(:).*ID(:));
    V_FR(iw) = sum(par.g(:).*ID(:).*withfiscalIRF.V(:));
    V_base(iw) = sum(par.g(:).*ID(:).*nofiscalIRF.V(:));
end

% Consumption equivalent

dV = withfiscalIRF.V - nofiscalIRF.V;
bprime = zeros(size(par.g));

for j=1:J
    for k = 1:K
        bprime(:,j,k) = interp1(par.vNew(:,j,k),grids.b,par.vNew(:,j,k) - dV(:,j,k));
        %bprime(:,j,k) = interp1(nofiscalIRF.V(:,j,k),grids.b,nofiscalIRF.V(:,j,k) - dV(:,j,k));
    end
end

compensation = grids.bbb - bprime; compensation(isnan(compensation))=0;

Npct = 10+1;
Comp = zeros(1,Npct);
pct = linspace(0,1,Npct)';
pct_w = interp1(G_w + threshold_gw'*10e-12,threshold_gw,pct);
pct_w(Npct) = bmax + amax;

for iw = 1:Npct-1
    %ID = abs(grids.aaa(:)+grids.bbb(:)-threshold_gw(iw))<=1;
    ID = (grids.aaa(:)+grids.bbb(:)<pct_w(iw+1)).*(grids.aaa(:)+grids.bbb(:)>=pct_w(iw));
    ID_mass = sum(par.g(:).*ID(:));
    Comp(iw) = sum(par.g(:).*ID(:).*compensation(:))/ID_mass;
end

Comp = Comp*par.GDP_stationary/par.numhh/par.Y; % normalize

close; set(gcf,'Position',[100 500 700 500])
b = bar(1:Npct-1,Comp(1:Npct-1));
b(1).FaceColor = c1;  % Consumption
ylabel('Compensation equivalente en euros','FontSize',15,'Interpreter','Latex');
xlabel('Deciles de richesse','FontSize',15,'Interpreter','Latex');
set(gca,'FontSize',20,'box','off','TickLabelInterpreter', 'latex');
print('-dpng', '-r300','../Output/distributionaleffects.png');

disp(['average compensation = ',num2str(mean(Comp))])


% Capital vs labor
% ========================================

delta_lab = withfiscalIRF.w_t .* withfiscalIRF.L_new_t./(nofiscalIRF.w_t .* nofiscalIRF.L_new_t)*100-100;
delta_cap = ((withfiscalIRF.ra_t+par.depreciation) .* withfiscalIRF.Kprod_t)./...
    ((nofiscalIRF.ra_t+par.depreciation) .* nofiscalIRF.Kprod_t)*100-100;

yearsplotted = 3.5;

close; set(gcf,'Position',[100 500 700 500])
hold on
plot(grids.time, delta_lab, 'LineWidth', 2, 'Color', c4);
plot(grids.time, delta_cap, 'LineWidth', 2, 'Color', c1);
plot(grids.time, grids.time * 0, '--', 'Color',[.7 .7 .7]);
legend({'Travail','Capital',''},'Box','off','Location','northeast','Interpreter', 'latex');
xlim([grids.time(1) grids.time(1)+ yearsplotted]);
ylabel('Gains dus a France Relance (pp)','FontSize',15,'Interpreter','Latex');
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');
xticks(grids.time);                       % Set tick positions
xticklabels(yearQuarter);        % Assign the year-quarter labels
xtickangle(45);                  % Optional: Rotate labels for readability
print('-dpng', '-r300','../Output/capitalvstravail.png');

disp(['average cap = ',num2str(mean(delta_cap(1:12)))])
disp(['average lab = ',num2str(mean(delta_lab(1:12)))])



%% EXPORT THE DATA


%% Figure 1 - Output Data
figure1_data = struct();
figure1_data.time = grids.time;
figure1_data.withfiscal_Y = withfiscalIRF.Y_t ./ par.Y * 100 - 100;
figure1_data.nofiscal_Y = nofiscalIRF.Y_t ./ par.Y * 100 - 100;
figure1_data.y_data = data.y_data * 100 - 100;

save('figure1.mat', 'figure1_data');

% Figure 2 - GDP Gain from Policy
figure2_data = struct();
figure2_data.time = grids.time;
figure2_data.output_gain = withfiscalIRF.Y_t ./ nofiscalIRF.Y_t * 100 - 100;
figure2_data.components = struct(...
    'consumption', (withfiscalIRF.C_t - nofiscalIRF.C_t) ./ nofiscalIRF.Y_t * 100, ...
    'investment', (withfiscalIRF.I_t - nofiscalIRF.I_t) ./ nofiscalIRF.Y_t * 100, ...
    'govt_expenditure', (Z_exo.G_t - par.G) ./ nofiscalIRF.Y_t * 100 ...
);

save('figure2.mat', 'figure2_data');

% Figure 3 - Employment Gain from Policy
figure3_data = struct();
figure3_data.time = grids.time;
figure3_data.emp_gain_pct = withfiscalIRF.L_t ./ nofiscalIRF.L_t * 100 - 100;
figure3_data.emp_gain_jobs = figure3_data.emp_gain_pct / 100 * par.employment / 1000;

save('figure3.mat', 'figure3_data');

% Figure 4 - Inflation and Price Level
figure4_data = struct();
figure4_data.time = time_inf;
figure4_data.inflation_diff = [0;pi_pa_t1]*100-[0;pi_pa_t2]*100;
figure4_data.price_level_ratio = [0;movmean(P1./P2,2)*100-100];

save('figure4.mat', 'figure4_data');

% Figure 5 - Sectoral Effects
figure5_data = struct();
figure5_data.time = grids.time;
figure5_data.output_gain_sectoral = withfiscalIRF.Ys_t ./ nofiscalIRF.Ys_t * 100 - 100;
figure5_data.weights = par.Ys .* par.Ps / sum(par.Ys .* par.Ps);
figure5_data.contribution_sectoral = figure5_data.output_gain_sectoral .* repmat(figure5_data.weights', length(grids.time), 1);

save('figure5.mat', 'figure5_data');

% Figure 6 - Decomposing Channels
figure6_data = cell(6, 1);
channel_names = {'varsigma_lON_IRF', 'varsigma_yON_IRF', 'varsigma_kON_IRF', 'GON_IRF', 'TON_IRF', 'withfiscalIRF'};
for i = 1:6
    channel_data = struct();
    channel_data.time = grids.time;
    channel_data.output_gain = channel{i}.Y_t ./ nofiscalIRF.Y_t * 100 - 100;
    channel_data.components = struct(...
        'consumption', (channel{i}.C_t - nofiscalIRF.C_t) ./ nofiscalIRF.Y_t * 100, ...
        'investment', (channel{i}.I_t - nofiscalIRF.I_t) ./ nofiscalIRF.Y_t * 100, ...
        'govt_expenditure', (Z_exo.G_t - par.G) ./ nofiscalIRF.Y_t * 100 ...
    );
    figure6_data{i} = channel_data;
    save(['figure6_' channel_names{i} '.mat'], 'channel_data');
end

% Figure 7 - Distributional Gains
figure7_data = struct();
figure7_data.percentiles = pct(1:10);
figure7_data.compensation = Comp(1:10)';

save('figure7.mat', 'figure7_data');


%% Appendix: debt

year_end = 2025;

close; set(gcf,'Position',[100 500 700 600])
hold on
plot(grids.time, withfiscalIRF.Bg_t./nofiscalIRF.Bg_t*100-100, 'LineWidth', 4, 'Color', c1);
xlim([grids.time(1) year_end]);
xticks(grids.time);              
xticklabels(yearQuarter);
xtickangle(45);    
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('points de pourcentages','FontSize',20,'Interpreter','Latex');
title('Hausse relative de la dette due a FR','FontSize',22,'Interpreter', 'latex');
print('-dpng', '-r300','../Output/dette.png');

%

deftogdp1 = withfiscalIRF.Bgdot_t./withfiscalIRF.Y_t; deftogdp1(1)=0;
deftogdp0 = nofiscalIRF.Bgdot_t./nofiscalIRF.Y_t; deftogdp0(1)=0;

close; set(gcf,'Position',[100 500 700 600])
hold on
plot(grids.time, deftogdp1*100-deftogdp0*100, 'LineWidth', 4, 'Color', c1);
xlim([grids.time(1) year_end]);
xticks(grids.time);              
xticklabels(yearQuarter);
xtickangle(45);    
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('points de PIB','FontSize',20,'Interpreter','Latex');
title('Hausse relative du deficit/PIB due a FR','FontSize',22,'Interpreter', 'latex');
print('-dpng', '-r300','../Output/deficit.png');

%

close; set(gcf,'Position',[100 500 700 600])
hold on
plot(grids.time, withfiscalIRF.tau_t*100-nofiscalIRF.tau_t*100, 'LineWidth', 4, 'Color', c1);
xlim([grids.time(1) year_end]);
xticks(grids.time);              
xticklabels(yearQuarter);
xtickangle(45);    
set(gca,'FontSize',18,'box','off','TickLabelInterpreter', 'latex');

xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('points de pourcentages','FontSize',20,'Interpreter','Latex');
title('Hausse relative des taxes sur le revenue due a FR','FontSize',22,'Interpreter', 'latex');
print('-dpng', '-r300','../Output/taxes.png');


%% Appendix: GDP GAIN FROM POLICY LONG

yearsplotted = 20;

par.fiscal_type = 'FranceRelance';
[Z_exo, par.n_endFS] = calibrate_tr_fn(par, grids,nofiscalIRF);

% Calculate the components for the stacked bar
output_gain = withfiscalIRF.Y_t ./ nofiscalIRF.Y_t * 100 - 100;
consumption = (withfiscalIRF.C_t - nofiscalIRF.C_t) ./ nofiscalIRF.Y_t * 100;
investment = (withfiscalIRF.I_t - nofiscalIRF.I_t) ./ nofiscalIRF.Y_t * 100;
govt_expenditure = (Z_exo.G_t - par.G) ./ nofiscalIRF.Y_t * 100;
netexp = (withfiscalIRF.Netexp - nofiscalIRF.Netexp)./ nofiscalIRF.Y_t * 100;
frictions = (withfiscalIRF.Fric_t - nofiscalIRF.Fric_t)./ nofiscalIRF.Y_t * 100;

% Combine the components into one matrix for the stacked bar
stacked_data = [consumption, investment, govt_expenditure]';

% Create the bar plot with decomposition
close; set(gcf,'Position',[100 500 1200 500])
hold on;
b = bar(grids.time, stacked_data, 'stacked');
aggregateoutput = plot(grids.time, output_gain-frictions,'-o','linewidth',2,'color',[1,1,1]/4);

b(1).FaceColor = par.c1;  % Consumption
b(2).FaceColor = par.c4;  % Investment
b(3).FaceColor = par.c2;  % Govt Expenditure

% Add legend and labels
legend({'Consommation', 'Investissement', 'Depense publique','Total'}, 'Box', 'off','FontSize',20,'Interpreter','Latex');
xlabel('Trimestre','FontSize',20,'Interpreter','Latex');
ylabel('Points de PIB','FontSize',20,'Interpreter','Latex');
xlim([grids.time(1)-.14 grids.time(1) + yearsplotted]);

% Format x-axis to show trimesters
xticks(grids.time);              
xticklabels(yearQuarter);      
xtickangle(45);      

hold off;
ax = gca; % Get current axes
ax.FontSize = 13; % Set font size of ticks
set(gca, 'TickLabelInterpreter', 'latex');
print('-dpng', '-r300','../Output/GDPgains_long.png');