function [Y_t,Bg_t,Bgdot_t,tau_t,Ah_new_t,Kprod_t, Bh_new_t, C_t, w_t, L_new_t,...
    L_t, rb_t, ra_t, PD_t, g_t, A_t, pi_t,Fric_t,V, Sb_t, Sa_t,Ys_t,Ks_t,Ls_t] = get_IRF(X, Z_exo, par, grids)
    
% Assign parameters
    cellfun(@(x) assignin('caller', x, Z_exo.(x)), fieldnames(Z_exo));
    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    cellfun(@(x) assignin('caller', x, grids.(x)), fieldnames(grids));
    
    % Endogeneous response
    
    K1_t = exp(X(1:N));
    L1_t = exp(X(N+1:2*N));
    rb_t = [X(2*N+1:end)];
    
    % Firm block
    % =========================================================================
    [Y_t, ra_t, w_t, Kprod_t, L_t, Ys_t, Ps_t, Ks_t, Ls_t] = block_firms_tr_fn(K1_t, L1_t, par, Z_exo);
    
    rk_t = ra_t + par.depreciation;

    %' Check for variables/moments to not get out of bound (just for safety;
    % shouldn't be invoked)
    % =========================================================================
    
        if (min(L_t)<0)
            ED_t = [100*ones(N,1); 100*ones(N-1,1); -1e6*(sign(L_t)-1).*ones(N,1)];
        elseif (min(Kprod_t)<0)
            ED_t = [1e6*(sign(Kprod_t)-1).*ones(N,1); 100*ones(N-1,1); 100*ones(N,1)];
        elseif (max(Kprod_t./Y_t) > 10)
            ED_t = [100*ones(N,1); 100*ones(N-1,1); 1e6*(sign(Kprod_t./Y_t - 7)+1).*ones(N,1)];
        elseif (min(rb_t) < -3*rho)
            ED_t = [100*ones(N,1); -1e6*(sign(rb_t(1:end-1)+rho)-1).*ones(N-1,1); 100*ones(N,1)];
        else
    
    
    % Government block
    % =========================================================================
    [Bg_t, Bgdot_t, tau_t, PD_t] = block_gov_tr_fn(w_t, rk_t, Ls_t, Ks_t, Ys_t, Ps_t, rb_t, par, Z_exo, grids.dt_F);

    
    % Household block
    % =========================================================================
    [Ah_new_t, Bh_new_t, C_t, g_t, A_t, Fric_t, V, Sb_t, Sa_t] = ...
        block_hh_tr_fn(ra_t, rb_t, w_t, L_t, tau_t, par, grids, Z_exo);

    % Union block
    % =========================================================================
    [L_new_t, pi_t] = block_union_tr_fn(ra_t, rb_t, w_t, C_t, tau_t, Ls_t, Ks_t, Y_t, Ys_t, par, grids, Z_exo);

    end
end