function [Bg_t, Bgdot_t, tau_t, PD_t] = block_gov_tr_fn(w_t, rk_t, Ls_t, Ks_t, Ys_t, Ps_t, rb_t, par, Z_exo, dt_F)
%{
  GOVERNMENT BLOCK
  ===========================================================================
%}

    cellfun(@(x) assignin('caller', x, par.(x)), fieldnames(par));
    
    Bgdot_t = zeros(N,1);

       
    L_t= sum(Ls_t, 2);

    varsigma_l_t = Z_exo.varsigma_l_t;
    varsigma_y_t = Z_exo.varsigma_y_t;
    varsigma_k_t = Z_exo.varsigma_k_t;
    G_t = Z_exo.G_t;
    T_t = Z_exo.T_t;

    switch fiscal_type
        case {'Baseline','FranceRelance','Decomposition','RelanceAlt', 'StickSS', 'LabourShock'}    
            % primary deficit & surplus
            PD_t = (G_t - Z_exo.tau_t.*w_t.*L_t + T_t ...
                         + w_t .* sum(varsigma_l_t./(1+ varsigma_l_t).*Ls_t, 2) ...
                         + rk_t .* sum(varsigma_k_t./(1+varsigma_k_t).*Ks_t, 2) ...
                         - sum(varsigma_y_t.*Ps_t.*Ys_t, 2));


            PS_t = -PD_t;


            % fiscal discretion period index: no change to taxes, debt
            % adjusts to satisfy gov inter-temporal budget constraint
            fisac_idx = 1:n_endFS-1;
            
            % Forward diff
            RHS_col = ((phi_r * rb - phi_b)*Bg + phi_l*(w_t.*L_t - w*L)).*dt_F;
            % adjust RHS for initial fiscal discretion period
            RHS_col(fisac_idx) = PS_t(fisac_idx).*dt_F(fisac_idx); 

            RHS_col(N) = RHS_col(N) + Bg;
                        
            diag_0 = (phi_r*rb_t - phi_b).*dt_F + 1;
            % adjust coef matrix for initial fiscal discretion period
            diag_0(fisac_idx) = rb_t(fisac_idx).*dt_F(fisac_idx) + 1;
            diag_u = -ones(N-1, 1);           

            coef_mat = diag(diag_0)+ diag(diag_u,1);


            Bg_t = coef_mat\RHS_col;           
            
            % Forward diff
            Bgdot_t(1:N-1) = (Bg_t(2:N) - Bg_t(1:N-1))./dt_F(1:N-1);
            Bgdot_t(N) = (Bg - Bg_t(N-1))/dt_F(N);

            tau_t = (rb_t.*Bg_t + G_t + T_t ...
                + w_t .* sum(varsigma_l_t./(1+ varsigma_l_t).*Ls_t, 2) ...
                + rk_t .* sum(varsigma_k_t./(1+varsigma_k_t).*Ks_t, 2) ...
                - sum(varsigma_y_t.*Ps_t.*Ys_t, 2) - Bgdot_t)./(w_t.*L_t);

        case 'else'

            % Forward diff
            RHS_col = ((phi_r * rb - phi_b)*Bg + phi_l*(w_t.*L_t - w*L)).*dt_F;
            RHS_col(N) = RHS_col(N) + Bg;
            
            diag_0 = (phi_r*rb_t - phi_b).*dt_F + 1;
            diag_u = -ones(N-1, 1);
            
            coef_mat = diag(diag_0)+ diag(diag_u,1);    
            
    
            Bg_t = coef_mat\RHS_col;
            
            % Forward diff
            Bgdot_t(1:N-1) = (Bg_t(2:N) - Bg_t(1:N-1))./dt_F(1:N-2);
            Bgdot_t(N) = (Bg - Bg_t(N-1))/dt_F(N);

            tau_t = (rb_t.*Bg_t + G_t + T_t ...
                + w_t .* sum(varsigma_l_t./(1+ varsigma_l_t).*Ls_t, 2) ...
                + rk_t .* sum(varsigma_k_t./(1+varsigma_k_t).*Ks_t, 2) ...
                - sum(varsigma_y_t.*Ps_t.*Ys_t, 2) - Bgdot_t)./(w_t.*L_t);

        otherwise

            % Forward diff
            RHS_col = ((phi_r * rb - phi_b)*Bg + phi_l*(w_t.*L_t - w*L)).*dt_F;
            RHS_col(N) = RHS_col(N) + Bg;
            
            diag_0 = (phi_r*rb_t - phi_b).*dt_F + 1;
            diag_u = -ones(N-1, 1);
            
            coef_mat = diag(diag_0)+ diag(diag_u,1);                
    
            Bg_t = coef_mat\RHS_col;

            % Forward diff
            Bgdot_t(1:N-1) = (Bg_t(2:N) - Bg_t(1:N-1))./dt_F(1:N-1);
            Bgdot_t(N) = (Bg - Bg_t(N-1))/dt_F(N);

            tau_t = (rb_t.*Bg_t + G_t + T_t ...
                + w_t .* sum(varsigma_l_t./(1+ varsigma_l_t).*Ls_t, 2) ...
                + rk_t .* sum(varsigma_k_t./(1+varsigma_k_t).*Ks_t, 2) ...
                - sum(varsigma_y_t.*Ps_t.*Ys_t, 2) - Bgdot_t)./(w_t.*L_t);

    end

end


